package com.stg.ex.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.stg.ex.dto.LeaveDto;
import com.stg.ex.dto.LoginCredentials;
import com.stg.ex.dto.UserDto;
import com.stg.ex.entity.Admin;
import com.stg.ex.entity.Leave;
import com.stg.ex.entity.User;
import com.stg.ex.exception.CustomException;
import com.stg.ex.entity.Holiday;
import com.stg.ex.service.AdminService;
import com.stg.ex.service.HolidaysService;
import com.stg.ex.service.LeaveService;
import com.stg.ex.service.UserService;
import com.stg.ex.utils.LeaveStatus;


@RestController
@RequestMapping("admin")
//@CrossOrigin("http://localhost:4200/")
@CrossOrigin("*")
public class AdminController {

	
	@Autowired(required = true)
	private AdminService adminService;

	@PostMapping(value="/add-admin")
	public  Admin addAdmin(@RequestBody Admin admin) {
		return adminService.addAdmin(admin);
	}
	
	@PutMapping("update-admin")	
	public  Admin updateAdmin(@RequestBody Admin admin)throws CustomException {
		int temp = 0;
		for(Admin localAdminr : adminService.getAllAdmin()) {
			if(localAdminr.getAdmin_id() == admin.getAdmin_id()) {
				temp = 1;
				break;
			}
		}
		if(temp == 1)
			return adminService.updateAdmin(admin);
		else
			throw new CustomException("Admin not found! Enter correct details..");
	}

	@DeleteMapping(value="/deleteadminbyId/{id}")
	public void deleteAdminById(@PathVariable int id) throws CustomException {
		int temp = 0;
		for(Admin localAdminr : adminService.getAllAdmin()) {
			if(localAdminr.getAdmin_id() == id) {
				temp = 1;
				adminService.deleteUserById(id);
				break;
			}
	}
		if(temp == 0)
				throw new CustomException("There is no Admin with that id: " + id);
	}
	
	@PostMapping(value = "/admin-login")
	//public Admin login(@PathVariable String username, @PathVariable String paswd) throws CustomException {
	public Admin login(@RequestBody LoginCredentials obj) throws CustomException {
		String username = obj.getEmpId();
		String password = obj.getPassword();
		int temp = 0;
		Admin admin1 = null;
		for(Admin admin : adminService.getAllAdmin()) {
			System.out.println("Frontend: "+username+ " "+ password);
			System.out.println("Backend: "+admin.getName() + admin.getPassword());
			if(admin.getName().equals(username) && admin.getPassword().equals(password)) {
				temp = 1;
				admin1 = admin;
				break;
			}
		}
		if(temp == 1)
			return admin1;
		else
			throw new CustomException("Invalid username or password");
	}
	
	@GetMapping(value="/getAdmin")
	public List<Admin> getAllAdmin() throws CustomException{
		if(adminService.getAllAdmin().size() != 0)
			return adminService.getAllAdmin();
		else
			throw new CustomException("No Admin Data");
	}
	

	/***************************************************************** User****************************************************/
	@PostMapping(value="/createUser")
	public  User createUser(@RequestBody User user)throws CustomException {
		if(user != null)
			return adminService.createUser(user);
		else
			throw new CustomException("Please Enter user details");
	} 

	@PutMapping("update-user")	
	public  User updateUser(@RequestBody User user)throws CustomException {
		int temp = 0;
		for(User localUser : adminService.getAllUsers()) {
			if(localUser.getUserId() == user.getUserId()) {
				temp = 1;
				break;
			}
		}
		if(temp == 1)
			return adminService.updateUser(user);
		else
			throw new CustomException("User not found! Enter correct details..");
	}

	@DeleteMapping(value="/deleteUserbyId/{id}")
	public void deleteUserById(@PathVariable int id) throws CustomException {
		int temp = 0;
		for(User localUser : adminService.getAllUsers()) {
			if(localUser.getUserId() == id) {
				temp = 1;
				adminService.deleteUserById(id);
				break;
			}
	}
		if(temp == 0)
				throw new CustomException("There is no user with that id: " + id);
	}
		
	@GetMapping(value="/getAllUser")
	public List<UserDto> getAllUsers()throws CustomException {
		if(adminService.getAllUsersDto().size() != 0)
			return adminService.getAllUsersDto();
		else
			throw new CustomException("No Users were registered yet");
	}
	
	@GetMapping(value="/getAllUserbyAdminIdDto/{id}")
	public List<UserDto> getAllUsersbyAdminIdDto(@PathVariable int id)throws CustomException {
		if(adminService.getAllUsersDtoByAdminId(id).size() != 0)
			return adminService.getAllUsersDtoByAdminId(id);
		else
			throw new CustomException("No Users were registered yet");
	}
	
	@GetMapping(value="/getAllUserbyAdminId/{id}")
	public List<User> getAllUsersbyAdminId(@PathVariable int id)throws CustomException {
		
		
		if(adminService.getAllUsersByAdminId(id).size() != 0)
			return adminService.getAllUsersByAdminId(id);
		else
			throw new CustomException("No Users were registered yet");
	}
	
	@GetMapping(value="/getAllUserp")
	public List<User> getAllUsersp()throws CustomException {
		if(adminService.getAllUsers().size() != 0)
			return adminService.getAllUsers();
		else
			throw new CustomException("No Users were registered yet");
	}


	/******************************************************Leave 
	 * @throws CustomException *********************************************************************************************/
	@GetMapping(value="/leavesInRange/{from}/{to}")
	public List<LeaveDto> leavesInRange(@PathVariable String from,@PathVariable String to) throws CustomException {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		System.out.println(from);
		LocalDate fromDate = LocalDate.parse(from,formatter);
		LocalDate toDate = LocalDate.parse(to,formatter);
		if(fromDate.isAfter(toDate))
			throw new CustomException("From-date Must be after to-date");
		else
				return adminService.leavesInRange(fromDate,toDate);
	}
	
	@GetMapping(value="/getAllLeaves")
	public List<LeaveDto> getAllLeavesByAdmin() throws CustomException{
		if(adminService.getAllLeavesByAdminDto() != null)
			return adminService.getAllLeavesByAdminDto();
		else
			throw new CustomException("No Leaves");
	}
	
	@GetMapping(value="/getAllPendingList")
	public List<LeaveDto> getPendingLeaves()throws CustomException{
		if(adminService.getPendingLeaves().size() != 0)
			return adminService.getPendingLeaves();
		else
			throw new CustomException("There is no pending approvals");
	}
	
	@GetMapping(value="/getPending-Approved")
	public List<LeaveDto> getPendingApprovedLeaves() throws CustomException{
		List<LeaveDto> leavesList = null;
		if(adminService.getApprovedLeaves().size() != 0 )
			leavesList.addAll(adminService.getApprovedLeaves());
		if(adminService.getPendingLeaves().size() != 0 )
			leavesList.addAll(adminService.getPendingLeaves());
		return leavesList;
	}


	@GetMapping(value="/getApprovedLeaves")
	public List<LeaveDto> getApprovedLeaves() throws CustomException{
		if(adminService.getApprovedLeaves().size() != 0)
			return adminService.getApprovedLeaves();
		else
			throw new CustomException("There is no Approved Leaves ");
	}


	@GetMapping(value="/getRejectedLeaves")
	public List<LeaveDto> getRejectedLeaves() throws CustomException{
		if(adminService.getRejectedLeaves().size() != 0)
			return adminService.getRejectedLeaves();
		else
			throw new CustomException("There is no Rejected Leaves ");
	}
	
	/***********************************************************************************************/
	@GetMapping(value="/getAllLeavesByAdminId/{id}")
	public List<LeaveDto> getAllLeavesByAdminId(@PathVariable int id) throws CustomException{
		if(adminService.getAllLeavesByAdminIdDto(id) != null)
			return adminService.getAllLeavesByAdminIdDto(id);
		else
			throw new CustomException("No Leaves");
	}
	
	@GetMapping(value="/getAllPendingListByAdminId/{id}")
	public List<LeaveDto> getPendingLeavesByAdminId(@PathVariable int id) throws CustomException{
		if(adminService.getPendingLeavesByAdminId(id).size() != 0)
			return adminService.getPendingLeavesByAdminId(id);
		else
			throw new CustomException("There is no pending approvals id: "+id);
	}
	


	@GetMapping(value="/getApprovedLeavesByAdminId/{id}")
	public List<LeaveDto> getApprovedLeavesByAdminId(@PathVariable int id) throws CustomException{
		if(adminService.getApprovedLeavesByAdminId(id).size() != 0)
			return adminService.getApprovedLeavesByAdminId(id);
		else
			throw new CustomException("There is no Approved Leaves ");
	}


	@GetMapping(value="/getRejectedLeavesByAdminId/{id}")
	public List<LeaveDto> getRejectedLeavesByAdminId(@PathVariable int id) throws CustomException{
		if(adminService.getRejectedLeavesByAdminId(id).size() != 0)
			return adminService.getRejectedLeavesByAdminId(id);
		else
			throw new CustomException("There is no Rejected Leaves ");
	}
	/*************************************************************************************************/


	//@PutMapping(value="/approveLeave/{leaveId}/{adminRemark}")
	//public Leave approveLeave(@PathVariable int leaveId, @PathVariable String adminRemark) throws CustomException {
	@PutMapping(value="/approveLeave/{leaveId}")
	public Leave approveLeave(@PathVariable int leaveId) throws CustomException {
		int temp = 0;
		Leave leave  = null;
		for(Leave localLeave : adminService.getAllLeavesByAdmin()) {
			if(localLeave.getLeaveId() == leaveId) {
				temp = 1;
				if(localLeave.getStatus() == LeaveStatus.ACCEPTED)
					throw new CustomException("This Leave Request is already approved");
				else if(localLeave.getStatus() == LeaveStatus.REJECTED)
					throw new CustomException("This Leave Request is already rejected");
				else {
					leave = localLeave;
					break;
				}
			}
		}
		if(temp == 0)
			throw new CustomException("There is no leave request with this id: " + leaveId);
		else
			return adminService.approveLeave(leave); 
			//return adminService.approveLeave(leave,adminRemark); 

		
		
	}

//	@PutMapping(value="/rejectLeave/{leaveId}/{adminRemark}")
//	public Leave rejectLeave(@PathVariable int leaveId, @PathVariable String adminRemark) throws CustomException {
	@PutMapping(value="/rejectLeave/{leaveId}")
	public Leave rejectLeave(@PathVariable int leaveId) throws CustomException {
		int temp = 0;
		Leave leave = null;
		for(Leave localLeave :adminService.getAllLeavesByAdmin()) {
			if(localLeave.getLeaveId() == leaveId) {
				temp = 1;
				if(localLeave.getStatus() == LeaveStatus.ACCEPTED)
					throw new CustomException("This Leave Request is already approved");
				else if(localLeave.getStatus() == LeaveStatus.REJECTED)
					throw new CustomException("This Leave Request is already rejected");
				else {
					leave = localLeave;
					break;
				}
			}
		}
		if(temp == 0)
			throw new CustomException("There is no leave request with this id: " + leave.getLeaveId());
		else
			//return adminService.rejectLeave(leave,adminRemark); 
			return adminService.rejectLeave(leave); 
		
	}

	//public abstract Optional<Leave> getLeaveById(int id) ;

	/*******************************************Holidays  ****************************** ********************/

	@PostMapping(value="/add-holidays-list")
	public List<Holiday> addHolidayList(@RequestBody List<Holiday> holidayList) throws CustomException {
		for(Holiday holiday: holidayList) {
			String isHoliday = adminService.isHolidayPresent(holiday);
			if(!isHoliday.equalsIgnoreCase("false"))
				throw new CustomException("This holiday is already added");
			if(holiday.getHolidayDate().getDayOfWeek().toString().equalsIgnoreCase("SUNDAY"))
				throw  new CustomException("Entered Holiday-Date is Sunday "+holiday.getHolidayDate());
			else if(holiday.getHolidayDate().getDayOfWeek().toString().equalsIgnoreCase("SATURDAY"))
				throw new CustomException("Entered Holiday-Date is Saturday " +holiday.getHolidayDate());
		}
		return adminService.addHolidaysList(holidayList);
	}
	
	@PostMapping(value="/add-holiday")
	public Holiday addHoliday(@RequestBody Holiday holiday ) throws CustomException {
		
		String isHoliday = adminService.isHolidayPresent(holiday);
		if(isHoliday.equalsIgnoreCase("true"))
			throw new CustomException("This holiday is already added");
		else if(holiday.getHolidayDate().getDayOfWeek().toString().equalsIgnoreCase("SUNDAY"))
			throw  new CustomException("Entered Holiday-Date is Sunday "+holiday.getHolidayDate());
		else if(holiday.getHolidayDate().getDayOfWeek().toString().equalsIgnoreCase("SATURDAY"))
			throw new CustomException("Entered Holiday-Date is Saturday " +holiday.getHolidayDate());
		else
			return adminService.addHoliday(holiday);
		
	}
	
	@PutMapping(value="/update-holiday")
	public Holiday updateHoliday(@RequestBody Holiday holiday ) throws CustomException {
		
		String isHoliday = adminService.isHolidayPresent(holiday);
		if(isHoliday.equalsIgnoreCase("false"))
			throw new CustomException("There is no holiday with this id : "+holiday.getHolidayId());
		else if(holiday.getHolidayDate().getDayOfWeek().toString().equalsIgnoreCase("SUNDAY"))
			throw  new CustomException("Entered Holiday-Date is Sunday "+holiday.getHolidayDate());
		else if(holiday.getHolidayDate().getDayOfWeek().toString().equalsIgnoreCase("SATURDAY"))
			throw new CustomException("Entered Holiday-Date is Saturday " +holiday.getHolidayDate());
		else
			return adminService.updateHoliday(holiday);
		
	}
	

	//public abstract Holidays addHoliday(Holidays holidays);

	@DeleteMapping("/delete-all-holiday")
	public void deleteHolidays() {
		adminService.deleteAllHolidays();
	}
	
	@DeleteMapping("/delete-holiday")
	public void deleteHolidayByid(@PathVariable int id) {
		adminService.deleteAllHolidays();
	}
	
	@GetMapping(value = "/holidayList")
	public List<Holiday> holidayList(){
		return adminService.getAllHolidayList();
	}

}
