package com.stg.ex.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;


public class CustomException extends Exception {
	private static final long serialVersionUID = 1L;
	private String errMsg;
	
	public CustomException(String errMsg) {
		super();
		this.errMsg = errMsg;
	}
	
	@Override
	public String getMessage() {
		return this.errMsg;
	}
}
