package com.stg.ex.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.stg.ex.utils.LeaveStatus;
import com.stg.ex.utils.LeaveType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="leave_tab")
public class Leave {
	@Id
	@Column(name = "leave_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int leaveId;

	@Column(name = "leave_reason", columnDefinition = "TEXT")
	private String leaveReason = "";

	@JsonFormat(pattern = "yyyy-MM-dd")
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Column(name = "from_date", nullable = false)
	private LocalDate fromDate;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Column(name = "to_date", nullable = false)
	private LocalDate toDate;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name = "created_at", nullable = false)
	@CreationTimestamp
	private LocalDateTime createdAt;

	@Column(name = "admin_remark", columnDefinition = "TEXT")
	private String adminRemark;

	@Column(name = "status", nullable = false)
	@Enumerated(EnumType.STRING)
	private LeaveStatus status = LeaveStatus.PENDING;

	@Column(name = "leave_type", nullable = false)
	@Enumerated(EnumType.STRING)
	private LeaveType leaveType = LeaveType.OTHERS;

	@Column(name = "no_of_days", nullable = false)
	private double noOfDays = 0.0;	
	@Column(name = "lop", nullable = false)
	private double lop = 0.0;

	@ManyToOne
	@JoinColumn(name = "user_id", nullable = false)
	@JsonBackReference
	private User userRef;


}



