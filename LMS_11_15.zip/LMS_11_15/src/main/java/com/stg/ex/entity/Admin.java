package com.stg.ex.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="admin_tab1")
public class Admin {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int admin_id;
	@Column(name="name", length=20)
	private String name;
	@Column(name="email", length=20)
	private String email;
	@Column(name="password", length=10)
	private String password;

	@JsonManagedReference
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "adminRef")
	private List<User> userList;
	/*
	@JsonManagedReference
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "adminRefHoliday")
	private List<Holiday> holidayList;



	/*
		@JsonManagedReference
		@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "adminRefLeave") // cascade means if teacher is deleted related students should be delete
		private List<Leave> leavesList;
	 */

}


