package com.stg.ex.serviceImplements;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stg.ex.dto.LeaveDto;
import com.stg.ex.entity.Holiday;
import com.stg.ex.entity.Leave;
import com.stg.ex.entity.User;
import com.stg.ex.exception.CustomException;
import com.stg.ex.repository.LeaveRepository;
import com.stg.ex.service.AdminService;
import com.stg.ex.service.HolidaysService;
import com.stg.ex.service.LeaveService;
import com.stg.ex.service.UserService;
import com.stg.ex.utils.Constants;
import com.stg.ex.utils.LeaveStatus;
import com.stg.ex.utils.LeaveType;
@Service
public class LeaveServiceimpl implements LeaveService{
	
	@Autowired(required = true)
	private UserService userService;

	@Autowired(required = true)
	private HolidaysService holidayService;

	@Autowired(required = true)
	private LeaveRepository leaveRepository;
	
	@Autowired(required = true)
	private AdminService adminservice;
	
	/********************************************************************************************/
	
//	@Override
//	public List<Leave> getAllLeavesByAdminId(int id) {
//		for(Admin admin)
//		return leaveRepository.findAll();
//	}
	
	@Override
	public List<LeaveDto> getAllLeavesByAdminDtoById(int id) {
		List<LeaveDto> leaveDtoList = new ArrayList<LeaveDto>();
		for(Leave leave : leaveRepository.findAll()) {
			if(leave.getUserRef().getAdminRef().getAdmin_id() == id) {
				LeaveDto leavedto = new LeaveDto();
	
				leavedto.setLeaveId(leave.getLeaveId());
				leavedto.setLeaveReason(leave.getLeaveReason());
				leavedto.setFromDate(leave.getFromDate());
				leavedto.setToDate(leave.getToDate());
				leavedto.setCreatedAt(leave.getCreatedAt());
				leavedto.setAdminRemark(leave.getAdminRemark());
				leavedto.setStatus(leave.getStatus());
				leavedto.setLeaveType(leave.getLeaveType());
				leavedto.setNoOfDays(leave.getNoOfDays());
				leavedto.setLop(leave.getLop());
				leavedto.setUserId(leave.getUserRef().getUserId());
				leavedto.setUsername(leave.getUserRef().getFirstName()+" "+leave.getUserRef().getLastName());
	
				leaveDtoList.add(leavedto);
			}
		}
		return leaveDtoList;
	}
	
	@Override
	public List<LeaveDto> getPendingLeavesByAdminId(int id) {
		List<Leave> pendingList = leaveRepository.findAll().stream().filter(p -> p.getStatus() == LeaveStatus.PENDING).collect(Collectors.toList());
		List<LeaveDto> pendingLeaveDtoList = new ArrayList<LeaveDto>();
		for(Leave leave : pendingList) {
			System.out.println("prnding 79 leaveservice: "+leave.getUserRef().getAdminRef().getAdmin_id());
			if(leave.getUserRef().getAdminRef().getAdmin_id() == id) {
				LeaveDto leavedto = new LeaveDto();

				leavedto.setLeaveId(leave.getLeaveId());
				leavedto.setLeaveReason(leave.getLeaveReason());
				leavedto.setFromDate(leave.getFromDate());
				leavedto.setToDate(leave.getToDate());
				leavedto.setCreatedAt(leave.getCreatedAt());
				leavedto.setAdminRemark(leave.getAdminRemark());
				leavedto.setStatus(leave.getStatus());
				leavedto.setLeaveType(leave.getLeaveType());
				leavedto.setNoOfDays(leave.getNoOfDays());
				leavedto.setLop(leave.getLop());
				leavedto.setUserId(leave.getUserRef().getUserId());
				leavedto.setUsername(leave.getUserRef().getFirstName()+" "+leave.getUserRef().getLastName());

				pendingLeaveDtoList.add(leavedto);
			}
		}
		return pendingLeaveDtoList;
		//return leaveRepository.findAll().stream().filter(p -> p.getStatus() == LeaveStatus.PENDING).collect(Collectors.toList());

	}
	@Override
	public List<LeaveDto> getApprovedLeavesByAdminId(int id) {
		List<Leave> approvedList = leaveRepository.findAll().stream().filter(p -> p.getStatus() == LeaveStatus.ACCEPTED).collect(Collectors.toList());
		List<LeaveDto> approvedLeaveDtoList = new ArrayList<LeaveDto>();
		for(Leave leave : approvedList) {
			System.out.println("prnding 79 leaveservice: "+leave.getUserRef().getAdminRef().getAdmin_id());
			if(leave.getUserRef().getAdminRef().getAdmin_id() == id) {
				LeaveDto leavedto = new LeaveDto();

				leavedto.setLeaveId(leave.getLeaveId());
				leavedto.setLeaveReason(leave.getLeaveReason());
				leavedto.setFromDate(leave.getFromDate());
				leavedto.setToDate(leave.getToDate());
				leavedto.setCreatedAt(leave.getCreatedAt());
				leavedto.setAdminRemark(leave.getAdminRemark());
				leavedto.setStatus(leave.getStatus());
				leavedto.setLeaveType(leave.getLeaveType());
				leavedto.setNoOfDays(leave.getNoOfDays());
				leavedto.setLop(leave.getLop());
				leavedto.setUserId(leave.getUserRef().getUserId());
				leavedto.setUsername(leave.getUserRef().getFirstName()+" "+leave.getUserRef().getLastName());

				approvedLeaveDtoList.add(leavedto);
			}
		}
		return approvedLeaveDtoList;
		//return leaveRepository.findAll().stream().filter(p -> p.getStatus() == LeaveStatus.PENDING).collect(Collectors.toList());

	}
	
	@Override
	public List<LeaveDto> getRejectedLeavesByAdminId(int id) {
		List<Leave> rejectList = leaveRepository.findAll().stream().filter(p -> p.getStatus() == LeaveStatus.REJECTED).collect(Collectors.toList());
		List<LeaveDto> rejectedLeaveDtoList = new ArrayList<LeaveDto>();
		for(Leave leave : rejectList) {
			System.out.println("prnding 79 leaveservice: "+leave.getUserRef().getAdminRef().getAdmin_id());
			if(leave.getUserRef().getAdminRef().getAdmin_id() == id) {
				LeaveDto leavedto = new LeaveDto();

				leavedto.setLeaveId(leave.getLeaveId());
				leavedto.setLeaveReason(leave.getLeaveReason());
				leavedto.setFromDate(leave.getFromDate());
				leavedto.setToDate(leave.getToDate());
				leavedto.setCreatedAt(leave.getCreatedAt());
				leavedto.setAdminRemark(leave.getAdminRemark());
				leavedto.setStatus(leave.getStatus());
				leavedto.setLeaveType(leave.getLeaveType());
				leavedto.setNoOfDays(leave.getNoOfDays());
				leavedto.setLop(leave.getLop());
				leavedto.setUserId(leave.getUserRef().getUserId());
				leavedto.setUsername(leave.getUserRef().getFirstName()+" "+leave.getUserRef().getLastName());

				rejectedLeaveDtoList.add(leavedto);
			}
		}
		return rejectedLeaveDtoList;
		//return leaveRepository.findAll().stream().filter(p -> p.getStatus() == LeaveStatus.PENDING).collect(Collectors.toList());

	}

	
	/********************************************************************************************/
	
	@Override
	public List<Leave> getAllLeavesByAdmin() {
		return leaveRepository.findAll();
	}
	

	@Override
	public Optional<Leave> getLeaveById(int id) {
		return leaveRepository.findById(id);
	}
	
	@Override
	public List<LeaveDto> getAllLeavesByAdminDto() {
		List<LeaveDto> leaveDtoList = new ArrayList<LeaveDto>();
		for(Leave leave : leaveRepository.findAll()) {
			LeaveDto leavedto = new LeaveDto();

			leavedto.setLeaveId(leave.getLeaveId());
			leavedto.setLeaveReason(leave.getLeaveReason());
			leavedto.setFromDate(leave.getFromDate());
			leavedto.setToDate(leave.getToDate());
			leavedto.setCreatedAt(leave.getCreatedAt());
			leavedto.setAdminRemark(leave.getAdminRemark());
			leavedto.setStatus(leave.getStatus());
			leavedto.setLeaveType(leave.getLeaveType());
			leavedto.setNoOfDays(leave.getNoOfDays());
			leavedto.setLop(leave.getLop());
			leavedto.setUserId(leave.getUserRef().getUserId());
			leavedto.setUsername(leave.getUserRef().getFirstName()+" "+leave.getUserRef().getLastName());

			leaveDtoList.add(leavedto);
		}
		return leaveDtoList;
	}
	
	@Override
	public List<LeaveDto> getAllLeavesByUserDto(int id) {
		List<LeaveDto> leaveDtoList = new ArrayList<LeaveDto>();
		for(Leave leave : leaveRepository.findAll()) {
			if(leave.getUserRef().getUserId() == id) {
				LeaveDto leavedto = new LeaveDto();
				leavedto.setLeaveId(leave.getLeaveId());
				leavedto.setLeaveReason(leave.getLeaveReason());
				leavedto.setFromDate(leave.getFromDate());
				leavedto.setToDate(leave.getToDate());
				leavedto.setCreatedAt(leave.getCreatedAt());
				leavedto.setAdminRemark(leave.getAdminRemark());
				leavedto.setStatus(leave.getStatus());
				leavedto.setLeaveType(leave.getLeaveType());
				leavedto.setNoOfDays(leave.getNoOfDays());
				leavedto.setLop(leave.getLop());
				leavedto.setUserId(leave.getUserRef().getUserId());
				leavedto.setUsername(leave.getUserRef().getFirstName()+" "+leave.getUserRef().getLastName());
				leaveDtoList.add(leavedto);
				
			}
			
		}
		return leaveDtoList;
	}

	@Override
	public List<LeaveDto> getPendingLeaves() {
		List<Leave> pendingList = leaveRepository.findAll().stream().filter(p -> p.getStatus() == LeaveStatus.PENDING).collect(Collectors.toList());
		List<LeaveDto> pendingLeaveDtoList = new ArrayList<LeaveDto>();
		for(Leave leave : pendingList) {
			LeaveDto leavedto = new LeaveDto();

			leavedto.setLeaveId(leave.getLeaveId());
			leavedto.setLeaveReason(leave.getLeaveReason());
			leavedto.setFromDate(leave.getFromDate());
			leavedto.setToDate(leave.getToDate());
			leavedto.setCreatedAt(leave.getCreatedAt());
			leavedto.setAdminRemark(leave.getAdminRemark());
			leavedto.setStatus(leave.getStatus());
			leavedto.setLeaveType(leave.getLeaveType());
			leavedto.setNoOfDays(leave.getNoOfDays());
			leavedto.setLop(leave.getLop());
			leavedto.setUserId(leave.getUserRef().getUserId());
			leavedto.setUsername(leave.getUserRef().getFirstName()+" "+leave.getUserRef().getLastName());

			pendingLeaveDtoList.add(leavedto);
		}
		return pendingLeaveDtoList;
		//return leaveRepository.findAll().stream().filter(p -> p.getStatus() == LeaveStatus.PENDING).collect(Collectors.toList());

	}
	
	@Override
	public List<LeaveDto> getPendingLeavesById(int id) {
		List<Leave> pendingList = leaveRepository.findAll().stream().filter(p -> p.getStatus() == LeaveStatus.PENDING).collect(Collectors.toList());
		List<LeaveDto> pendingLeaveDtoList = new ArrayList<LeaveDto>();
		for(Leave leave : pendingList) {
			if(leave.getUserRef().getUserId() == id) {
				LeaveDto leavedto = new LeaveDto();

				leavedto.setLeaveId(leave.getLeaveId());
				leavedto.setLeaveReason(leave.getLeaveReason());
				leavedto.setFromDate(leave.getFromDate());
				leavedto.setToDate(leave.getToDate());
				leavedto.setCreatedAt(leave.getCreatedAt());
				leavedto.setAdminRemark(leave.getAdminRemark());
				leavedto.setStatus(leave.getStatus());
				leavedto.setLeaveType(leave.getLeaveType());
				leavedto.setNoOfDays(leave.getNoOfDays());
				leavedto.setLop(leave.getLop());
				leavedto.setUserId(leave.getUserRef().getUserId());
				leavedto.setUsername(leave.getUserRef().getFirstName()+" "+leave.getUserRef().getLastName());

				pendingLeaveDtoList.add(leavedto);
			}
		}
		return pendingLeaveDtoList;
		//return leaveRepository.findAll().stream().filter(p -> p.getStatus() == LeaveStatus.PENDING).collect(Collectors.toList());

	}

	@Override
	public List<LeaveDto> getApprovedLeaves() {
		List<Leave> approvedList = leaveRepository.findAll().stream().filter(p -> p.getStatus() == LeaveStatus.ACCEPTED).collect(Collectors.toList());
		List<LeaveDto> approvedleaveDtoList = new ArrayList<LeaveDto>();
		for(Leave leave : approvedList) {
			LeaveDto leavedto = new LeaveDto();

			leavedto.setLeaveId(leave.getLeaveId());
			leavedto.setLeaveReason(leave.getLeaveReason());
			leavedto.setFromDate(leave.getFromDate());
			leavedto.setToDate(leave.getToDate());
			leavedto.setCreatedAt(leave.getCreatedAt());
			leavedto.setAdminRemark(leave.getAdminRemark());
			leavedto.setStatus(leave.getStatus());
			leavedto.setLeaveType(leave.getLeaveType());
			leavedto.setNoOfDays(leave.getNoOfDays());
			leavedto.setLop(leave.getLop());
			leavedto.setUserId(leave.getUserRef().getUserId());
			leavedto.setUsername(leave.getUserRef().getFirstName()+" "+leave.getUserRef().getLastName());

			approvedleaveDtoList.add(leavedto);
		}
		return approvedleaveDtoList;

	}
	
	@Override
	public List<LeaveDto> getApprovedLeavesById(int id) {
		List<Leave> approvedList = leaveRepository.findAll().stream().filter(p -> p.getStatus() == LeaveStatus.ACCEPTED).collect(Collectors.toList());
		List<LeaveDto> approvedleaveDtoList = new ArrayList<LeaveDto>();
		for(Leave leave : approvedList) {
			if(leave.getUserRef().getUserId() == id) {
				LeaveDto leavedto = new LeaveDto();
	
				leavedto.setLeaveId(leave.getLeaveId());
				leavedto.setLeaveReason(leave.getLeaveReason());
				leavedto.setFromDate(leave.getFromDate());
				leavedto.setToDate(leave.getToDate());
				leavedto.setCreatedAt(leave.getCreatedAt());
				leavedto.setAdminRemark(leave.getAdminRemark());
				leavedto.setStatus(leave.getStatus());
				leavedto.setLeaveType(leave.getLeaveType());
				leavedto.setNoOfDays(leave.getNoOfDays());
				leavedto.setLop(leave.getLop());
				leavedto.setUserId(leave.getUserRef().getUserId());
				leavedto.setUsername(leave.getUserRef().getFirstName()+" "+leave.getUserRef().getLastName());
	
				approvedleaveDtoList.add(leavedto);
			}
		}
		return approvedleaveDtoList;

	}

	@Override
	public List<LeaveDto> getRejectedLeaves() {
		List<Leave> rejectedList = leaveRepository.findAll().stream().filter(p -> p.getStatus() == LeaveStatus.REJECTED).collect(Collectors.toList());
		List<LeaveDto> rejectedleaveDtoList = new ArrayList<LeaveDto>();
		for(Leave leave : rejectedList) {
			LeaveDto leavedto = new LeaveDto();

			leavedto.setLeaveId(leave.getLeaveId());
			leavedto.setLeaveReason(leave.getLeaveReason());
			leavedto.setFromDate(leave.getFromDate());
			leavedto.setToDate(leave.getToDate());
			leavedto.setCreatedAt(leave.getCreatedAt());
			leavedto.setAdminRemark(leave.getAdminRemark());
			leavedto.setStatus(leave.getStatus());
			leavedto.setLeaveType(leave.getLeaveType());
			leavedto.setNoOfDays(leave.getNoOfDays());
			leavedto.setLop(leave.getLop());
			leavedto.setUserId(leave.getUserRef().getUserId());
			leavedto.setUsername(leave.getUserRef().getFirstName()+" "+leave.getUserRef().getLastName());

			rejectedleaveDtoList.add(leavedto);
		}
		return rejectedleaveDtoList;

	}
	@Override
	public List<LeaveDto> getRejectedLeavesById(int id) {
		List<Leave> rejectedList = leaveRepository.findAll().stream().filter(p -> p.getStatus() == LeaveStatus.REJECTED).collect(Collectors.toList());
		List<LeaveDto> rejectedleaveDtoList = new ArrayList<LeaveDto>();
		for(Leave leave : rejectedList) {
			if(leave.getUserRef().getUserId() == id) {
				LeaveDto leavedto = new LeaveDto();
	
				leavedto.setLeaveId(leave.getLeaveId());
				leavedto.setLeaveReason(leave.getLeaveReason());
				leavedto.setFromDate(leave.getFromDate());
				leavedto.setToDate(leave.getToDate());
				leavedto.setCreatedAt(leave.getCreatedAt());
				leavedto.setAdminRemark(leave.getAdminRemark());
				leavedto.setStatus(leave.getStatus());
				leavedto.setLeaveType(leave.getLeaveType());
				leavedto.setNoOfDays(leave.getNoOfDays());
				leavedto.setLop(leave.getLop());
				leavedto.setUserId(leave.getUserRef().getUserId());
				leavedto.setUsername(leave.getUserRef().getFirstName()+" "+leave.getUserRef().getLastName());
	
				rejectedleaveDtoList.add(leavedto);
			}
		}
		return rejectedleaveDtoList;

	}
/*
	@Override
	public Leave approveLeave(Leave leave, String adminRemark) {
		leave.setStatus(LeaveStatus.ACCEPTED);
		leave.setAdminRemark(adminRemark);
		if(leave.getLeaveType() == LeaveType.HALF_DAY_LEAVE) {
			return halfDayLeave(leave);
		}
		else {
			long noOfLeaves = ChronoUnit.DAYS.between(leave.getFromDate(), leave.getToDate())+1;
			if(leave.getLeaveType() == LeaveType.MATERNITY_LEAVE) {
				return maternityLeave(leave,noOfLeaves);
			}
			else if(leave.getLeaveType() == LeaveType.PATERNITY_LEAVE) {
				return paternityLeave(leave,noOfLeaves);
			}

			else {
				noOfLeaves = noOfLeaves(leave.getFromDate(),leave.getToDate());
				return othersLeave(leave, noOfLeaves);
			}
		}
	}
	*/
	
	@Override
	public Leave approveLeave1(Leave leave) {
		/*
		leave.setStatus(LeaveStatus.ACCEPTED);

		if(leave.getLeaveType() == LeaveType.HALF_DAY_LEAVE) {
			return halfDayLeave(leave);
		}
		else {
			long noOfLeaves = ChronoUnit.DAYS.between(leave.getFromDate(), leave.getToDate())+1;
			if(leave.getLeaveType() == LeaveType.MATERNITY_LEAVE) {
				return maternityLeave(leave,noOfLeaves);
			}
			else if(leave.getLeaveType() == LeaveType.PATERNITY_LEAVE) {
				return paternityLeave(leave,noOfLeaves);
			}

			else {
				noOfLeaves = noOfLeaves(leave.getFromDate(),leave.getToDate());
				return othersLeave(leave, noOfLeaves);
			}
		}
		*/
		return null;
	}
	
	@Override
	public Leave approveLeave(Leave leave,User user) {
		leave.setStatus(LeaveStatus.ACCEPTED);

		if(leave.getLeaveType() == LeaveType.HALF_DAY_LEAVE) {
			return halfDayLeave(leave,user);
		}
		else {
			long noOfLeaves = ChronoUnit.DAYS.between(leave.getFromDate(), leave.getToDate())+1;
			if(leave.getLeaveType() == LeaveType.MATERNITY_LEAVE) {
				return maternityLeave(leave,noOfLeaves,user);
			}
			else if(leave.getLeaveType() == LeaveType.PATERNITY_LEAVE) {
				return paternityLeave(leave,noOfLeaves,user);
			}

			else {
				noOfLeaves = noOfLeaves(leave.getFromDate(),leave.getToDate());
				return othersLeave(leave, noOfLeaves,user);
			}
		}
	}
/*
	@Override
	public Leave rejectLeave(Leave leave, String adminRemark) {
		leave.setStatus(LeaveStatus.REJECTED);
		leave.setAdminRemark(adminRemark);
		leave.setLop(0);
		leaveRepository.save(leave);
		return leave;
	}
*/
	@Override
	public Leave rejectLeave(Leave leave) {
		leave.setStatus(LeaveStatus.REJECTED);
		
		leave.setLop(0);
		leaveRepository.save(leave);
		return leave;
	}
	public Leave maternityLeave(Leave leave, long noOfLeaves,User user) {
		if(noOfLeaves > Constants.MATERNITY_LEAVES) {
			long remaining_days = noOfLeaves - Constants.MATERNITY_LEAVES;
			if(user.getLeave_bal() > 0) {
				if(user.getLeave_bal() - remaining_days >= 0) {
					user.setLeave_bal(user.getLeave_bal() - remaining_days);
				}
				else {
					leave.setLop(Math.abs(user.getLeave_bal() - remaining_days));
					user.setLeave_bal(0);
				}
			}
			else {
				leave.setLop(Math.abs(remaining_days));
				user.setLeave_bal(0);
			}

		}
		userService.updateUser(user);
		leaveRepository.save(leave);
		return leave;
	}

	public Leave paternityLeave(Leave leave, long noOfLeaves,User user) {
		if(noOfLeaves > Constants.PATERNITY_LEAVES) {
			long remaining_days = noOfLeaves - Constants.PATERNITY_LEAVES;
			if(user.getLeave_bal() > 0) {
				if(user.getLeave_bal() - remaining_days >= 0) {
					user.setLeave_bal(user.getLeave_bal() - remaining_days);
				}
				else {
					leave.setLop(remaining_days - user.getLeave_bal() );
					user.setLeave_bal(0);
				}
			}
			else {
				leave.setLop(Math.abs(remaining_days));
				user.setLeave_bal(0);
			}

		}
		userService.updateUser(user);
		leaveRepository.save(leave);
		return leave;
	}

	public Leave othersLeave(Leave leave, long noOfLeaves,User user) {
		if(user.getLeave_bal() > 0) {
			if(user.getLeave_bal() - noOfLeaves >= 0) {
				user.setLeave_bal(user.getLeave_bal() - noOfLeaves);
			}
			else {
				leave.setLop(Math.abs(user.getLeave_bal() - noOfLeaves));
				user.setLeave_bal(0);
			}
		}
		else {
			leave.setLop(Math.abs(noOfLeaves));
			user.setLeave_bal(0);
		}
		userService.updateUser(user);
		leaveRepository.save(leave);
		return leave;
	}

	public Leave halfDayLeave(Leave leave,User user) {
		leave.setNoOfDays(0.5);
		if(user.getLeave_bal() > 0) 
			user.setLeave_bal(user.getLeave_bal()-0.5);
		else
			leave.setLop(0.5);
		System.out.println("approve halfday leave leaveService 395; ");
		System.out.println(leave.getLop());
		userService.updateUser(user);
		leaveRepository.save(leave);
		return leave;
	}
	
	
	/*
	public Leave maternityLeave(Leave leave, long noOfLeaves) {
		if(noOfLeaves > Constants.MATERNITY_LEAVES) {
			long remaining_days = noOfLeaves - Constants.MATERNITY_LEAVES;
			if(leave.getUserRef().getLeave_bal() > 0) {
				if(leave.getUserRef().getLeave_bal() - remaining_days >= 0) {
					leave.getUserRef().setLeave_bal(leave.getUserRef().getLeave_bal() - remaining_days);
				}
				else {
					leave.setLop(Math.abs(leave.getUserRef().getLeave_bal() - remaining_days));
					leave.getUserRef().setLeave_bal(0);
				}
			}
			else {
				leave.setLop(Math.abs(remaining_days));
				leave.getUserRef().setLeave_bal(0);
			}

		}
		userService.updateUser(leave.getUserRef());
		leaveRepository.save(leave);
		return leave;
	}

	public Leave paternityLeave(Leave leave, long noOfLeaves) {
		if(noOfLeaves > Constants.PATERNITY_LEAVES) {
			long remaining_days = noOfLeaves - Constants.PATERNITY_LEAVES;
			if(leave.getUserRef().getLeave_bal() > 0) {
				if(leave.getUserRef().getLeave_bal() - remaining_days >= 0) {
					leave.getUserRef().setLeave_bal(leave.getUserRef().getLeave_bal() - remaining_days);
				}
				else {
					leave.setLop(remaining_days - leave.getUserRef().getLeave_bal() );
					leave.getUserRef().setLeave_bal(0);
				}
			}
			else {
				leave.setLop(Math.abs(remaining_days));
				leave.getUserRef().setLeave_bal(0);
			}

		}
		userService.updateUser(leave.getUserRef());
		leaveRepository.save(leave);
		return leave;
	}

	public Leave othersLeave(Leave leave, long noOfLeaves) {
		if(leave.getUserRef().getLeave_bal() > 0) {
			if(leave.getUserRef().getLeave_bal() - noOfLeaves >= 0) {
				leave.getUserRef().setLeave_bal(leave.getUserRef().getLeave_bal() - noOfLeaves);
			}
			else {
				leave.setLop(Math.abs(leave.getUserRef().getLeave_bal() - noOfLeaves));
				leave.getUserRef().setLeave_bal(0);
			}
		}
		else {
			leave.setLop(Math.abs(noOfLeaves));
			leave.getUserRef().setLeave_bal(0);
		}
		userService.updateUser(leave.getUserRef());
		leaveRepository.save(leave);
		return leave;
	}

	public Leave halfDayLeave(Leave leave) {
		leave.setNoOfDays(0.5);
		if(leave.getUserRef().getLeave_bal() > 0) 
			leave.getUserRef().setLeave_bal(leave.getUserRef().getLeave_bal()-0.5);
		else
			leave.setLop(0.5);
		System.out.println("approve halfday leave leaveService 395; ");
		System.out.println(leave.getLop());
		userService.updateUser(leave.getUserRef());
		leaveRepository.save(leave);
		return leave;
	}
	
	*/
	@Override
	public List<LeaveDto> leavesInRange(LocalDate from, LocalDate to) throws CustomException  {
		List<LeaveDto> leaveList = new ArrayList<LeaveDto>();
		if(from.isAfter(to))
			throw new CustomException("From date must be before to To-Date");
		else {
			for(LeaveDto leave : getAllLeavesByAdminDto()) {
				if(leave.getFromDate().isEqual(from) || isWithinRange(leave.getFromDate(),from, to) 
						|| (leave.getFromDate().isEqual(to)) || (leave.getToDate().isEqual(from))
						|| (isWithinRange(leave.getToDate(),from, to)) || (leave.getToDate().isEqual(to)) ){
					leaveList.add(leave);
					//System.out.println("leave.getFromDate().isEqual(from) " + leave.getLeaveId());
				}
				/*
				else if(isWithinRange(leave.getFromDate(),from, to)) {
					//System.out.println("isWithinRange(leave.getFromDate(),from, to) " + leave.getLeaveId());
					leaveList.add(leave);
				}
				else if(leave.getFromDate().isEqual(to)) {
					//System.out.println("leave.getFromDate().isEqual(to) " + leave.getLeaveId());
					leaveList.add(leave);
				}
				else  if(leave.getToDate().isEqual(from)){
					leaveList.add(leave);
					//System.out.println("leave.getToDate().isEqual(from) " + leave.getLeaveId());
				}
				else if(isWithinRange(leave.getToDate(),from, to)) {
					//System.out.println("isWithinRange(leave.getToDate(),from, to) " + leave.getLeaveId());
					leaveList.add(leave);
				}
				else if(leave.getToDate().isEqual(to)) {
					//System.out.println("leave.getToDate().isEqual(to) " + leave.getLeaveId());
					leaveList.add(leave);
				}
				*/
			}
			return leaveList;
		}		
		
	}

	public boolean isWithinRange(LocalDate testDate,LocalDate from, LocalDate to) {
		return (testDate.isAfter(from)) &&( testDate.isBefore(to) );
	}
	@Override
	public Leave applyLeave(Leave leave,User user) throws CustomException {	
		
		double user_leave_bal = user.getLeave_bal();
		
		System.out.println("456 :"+user_leave_bal);
		if(leave.getLeaveType() == LeaveType.HALF_DAY_LEAVE) {
			if(leave.getFromDate().isEqual(leave.getToDate())) {
				leave.setNoOfDays(0.5);
				leave.setLop(lop(leave,user_leave_bal));
				return leaveRepository.save(leave);
			}
			else
				throw new CustomException("While applying HALF_DAY_LEAVE from-date and to-date must be same");
		}
		else 
			if(leave.getLeaveType() == LeaveType.MATERNITY_LEAVE || leave.getLeaveType() == LeaveType.PATERNITY_LEAVE) {
				leave.setNoOfDays(ChronoUnit.DAYS.between(leave.getFromDate(), leave.getToDate())+1);
				leave.setLop(lop(leave,user_leave_bal));
				System.out.println("469 lop mater: "+lop(leave,user_leave_bal));
				return leaveRepository.save(leave);
			}
			else if(leave.getLeaveType() == LeaveType.SICK_lEAVE || leave.getLeaveType() == LeaveType.CASUAL_LEAVE || 
					leave.getLeaveType() == LeaveType.OTHERS) {
				System.out.println("474 leavetype: " +leave.getLeaveType()+"nofleaves "+noOfLeaves(leave.getFromDate(),leave.getToDate()) );
				
				if(leave.getFromDate().isEqual(leave.getToDate()))
					leave.setNoOfDays(1);
				else
					leave.setNoOfDays(noOfLeaves(leave.getFromDate(),leave.getToDate()));

				leave.setLop(lop(leave,user_leave_bal));
				System.out.println("Lop other: 477: "+lop(leave,user_leave_bal));
				return leaveRepository.save(leave);
			}


		return leaveRepository.save(leave);


	}
/*	
	public Leave applyLeave1(Leave leave) throws CustomException {
		
		if(LocalDate.now().isAfter(leave.getFromDate()))
			throw new CustomException("From date must be After or equal to Today");
		
		if(leave.getFromDate().isAfter(leave.getToDate()))
			throw new CustomException("From date must be before to To-Date");
		
		else {
			if(isHoliday(leave.getFromDate()))
				throw new CustomException("From-Date that you have entered is Holiday");

			else if(isHoliday(leave.getToDate()))
				throw new CustomException("To-Date that you have entered is Holiday");

			else if(leave.getFromDate().getDayOfWeek().toString().equalsIgnoreCase("SATURDAY"))
				throw new CustomException("From-Date that you have entered is SATURDAY");

			else if(leave.getFromDate().getDayOfWeek().toString().equalsIgnoreCase("SUNDAY"))
				throw new CustomException("From-Date that you have entered is SUNDAY");

			if(leave.getToDate().getDayOfWeek().toString().equalsIgnoreCase("SATURDAY"))
				throw new CustomException("To-Date that you have entered is SATURDAY");

			else if(leave.getToDate().getDayOfWeek().toString().equalsIgnoreCase("SUNDAY"))
				throw new CustomException("To-Date that you have entered is SUNDAY");
			
			else{
				if(leave.getLeaveType() == LeaveType.HALF_DAY_LEAVE) {
					if(leave.getFromDate().isEqual(leave.getToDate())) {
						leave.setNoOfDays(0.5);
						leave.setLop(lop(leave));
						return leaveRepository.save(leave);
					}
					else
						throw new CustomException("While applying HALF_DAY_LEAVE from-date and to-date must be same");
				}
				else {
					if(leave.getLeaveType() == LeaveType.MATERNITY_LEAVE || leave.getLeaveType() == LeaveType.PATERNITY_LEAVE) {
						leave.setNoOfDays(ChronoUnit.DAYS.between(leave.getFromDate(), leave.getToDate())+1);
					}
					else if(leave.getLeaveType() == LeaveType.SICK_lEAVE || leave.getLeaveType() == LeaveType.CASUAL_LEAVE || 
							leave.getLeaveType() == LeaveType.OTHERS) {
						System.out.println("494 " +leave.getLeaveType()+" "+noOfLeaves(leave.getFromDate(),leave.getToDate()) );
						leave.setNoOfDays(noOfLeaves(leave.getFromDate(),leave.getToDate()));
					}
					leave.setLop(lop(leave));
				}
				return leaveRepository.save(leave);
			}
		}
	}
	*/
	
	public double lop(Leave leave,double user_leave_bal) {

		long noOfLeaves = ChronoUnit.DAYS.between(leave.getFromDate(), leave.getToDate())+1;
		System.out.println("548 noOfLeaves : " + noOfLeaves);
		if(leave.getLeaveType() == LeaveType.MATERNITY_LEAVE ) {
			if(noOfLeaves > Constants.MATERNITY_LEAVES) {
				long remaining_days = noOfLeaves - Constants.MATERNITY_LEAVES;
				if(user_leave_bal > 0) {
					if(user_leave_bal - remaining_days >= 0) {
						return 0;
						//leave.setLop(0);
					}
					else {
						//leave.setLop(Math.abs(leave.getUserRef().getLeave_bal() - remaining_days));
						return Math.abs(user_leave_bal - remaining_days);
					}
				}
				else {
					//leave.setLop(Math.abs(remaining_days));
					System.out.println("remaining days : " + remaining_days);
					return remaining_days;
				} 
			}
			else
				return 0;
		}
		else if(leave.getLeaveType() == LeaveType.PATERNITY_LEAVE ) {
			if(noOfLeaves > Constants.PATERNITY_LEAVES) {
				long remaining_days = noOfLeaves - Constants.PATERNITY_LEAVES;
				if(user_leave_bal > 0) {
					if(user_leave_bal - remaining_days >= 0) {
						return 0;
						//leave.setLop(0);
					}
					else {
						//leave.setLop(Math.abs(leave.getUserRef().getLeave_bal() - remaining_days));
						return Math.abs(user_leave_bal - remaining_days);
					}
				}
				else {
					//leave.setLop(Math.abs(remaining_days));
					return remaining_days;
				} 
			}
			else
				return 0;
		}
		else if(leave.getLeaveType() == LeaveType.SICK_lEAVE || leave.getLeaveType() == LeaveType.CASUAL_LEAVE || 
				leave.getLeaveType() == LeaveType.OTHERS|| leave.getLeaveType() == LeaveType.HALF_DAY_LEAVE) {
			Long totalDays = noOfLeaves(leave.getFromDate(), leave.getToDate());
			System.out.println("553:leave bal other " +user_leave_bal+"Leave Ref "+leave.getUserRef());
			
			if(user_leave_bal > 0) {
				if(user_leave_bal - totalDays >= 0) {
					System.out.println("have leaveBal 555 line"+ 0);
					return 0;
					//leave.setLop(0);
				}
				else {
					//leave.setLop(Math.abs(leave.getUserRef().getLeave_bal() - remaining_days));
					System.out.println("Less leave Bakl 561line "+Math.abs(totalDays - user_leave_bal ));
					return Math.abs(totalDays - user_leave_bal );
					
				}
			}
			else {
				System.out.println("No Leave bal 0 other total days : 567 :" + totalDays);
				if(leave.getLeaveType() == LeaveType.HALF_DAY_LEAVE)
					return 0.5;
				else
					return totalDays;
				
			}
		}
		System.out.println("Unreach code in leaveservice 611 : ");
		return 0;
			
	}
	
	/*
		 if(noOfLeaves > Constants.MATERNITY_LEAVES) {
			long remaining_days = noOfLeaves - Constants.MATERNITY_LEAVES;
			if(leave.getUserRef().getLeave_bal() > 0) {
				if(leave.getUserRef().getLeave_bal() - remaining_days >= 0) {
					leave.getUserRef().setLeave_bal(leave.getUserRef().getLeave_bal() - remaining_days);
				}
				else {
					leave.setLop(Math.abs(leave.getUserRef().getLeave_bal() - remaining_days));
					leave.getUserRef().setLeave_bal(0);
				}
			}
			else {
				leave.setLop(Math.abs(remaining_days));
				leave.getUserRef().setLeave_bal(0);
			} 

	 */

/*
		if(leave.getLeaveType() == LeaveType.HALF_DAY_LEAVE)
			leave.setNoOfDays(0.5);
		else
			leave.setNoOfDays(noOfLeaves(leave.getFromDate(),leave.getToDate())+1);
		return leaveRepo.save(leave);
 */

public long noOfLeaves(LocalDate fromDate, LocalDate toDate) {
//	String from = fromDate.toString();
//	String to = toDate.toString();
//	
//	System.out.println("651 : "+from);
	/*
	List<LocalDate> holidayDates;
	for(Holiday holiday : holidayService.getAllHolidayList()) {
		holidayDates.add(holiday.getHolidayDate());
	}
	
	Predicate<LocalDate> isHoliday = date -> holidayDates.isPresent()
            && holidayDates.get().contains(date);

	// Predicate 2: Is a given date is a weekday
	Predicate<LocalDate> isWeekend = date -> date.getDayOfWeek() == DayOfWeek.SATURDAY
	        || date.getDayOfWeek() == DayOfWeek.SUNDAY;
	
	// Iterate over stream of all dates and check each day against any weekday or holiday
	List<LocalDate> businessDays = startDate.datesUntil(endDate)
	        .filter(isWeekend.or(isHoliday).negate())
	        .collect(Collectors.toList());
	//Set<DayOfWeek> weekend = EnumSet.of(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY);
	*/
	long days = fromDate.datesUntil(toDate)
				.filter(d -> !(isWeekend(d) || isHoliday(d)))
				.count();
	int businessDays = 0;
   // LocalDate d = startInclusive;
	
    while (fromDate.isBefore(toDate)||fromDate.isEqual(toDate)) {
      DayOfWeek dw = fromDate.getDayOfWeek();
      if (!isHoliday(fromDate) && dw != DayOfWeek.SATURDAY && dw != DayOfWeek.SUNDAY) {
        businessDays++;
      }
      fromDate = fromDate.plusDays(1);
    }
    System.out.println("688:line no of leaves bussiness days: "+businessDays); 
	//10/08/2013
	/*
	DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
    Date date1 = df.parse(from);
   Date date2 = df.parse(to);
    Calendar cal1 = Calendar.getInstance();
    Calendar cal2 = Calendar.getInstance();
    cal1.setTime(date1);
    
   cal2.setTime(date2);

    int numberOfDays = 0;
    while (cal1.before(cal2)) {
        if ((Calendar.SATURDAY != cal1.get(Calendar.DAY_OF_WEEK))
          &&(Calendar.SUNDAY != cal1.get(Calendar.DAY_OF_WEEK))) {
         numberOfDays++;
        }
       cal1.add(Calendar.DATE,1);
    }
    System.out.println(numberOfDays);
*/
	
	
	/*
	final long weekDaysBetween = fromDate.datesUntil(toDate)
			.filter(d -> (!(weekend.contains(d.getDayOfWeek()))(isHoliday(d))))
			.count();
			
	// Iterate over stream of all dates and check each day against any weekday or holiday
	List<LocalDate> businessDays = startDate.datesUntil(endDate)
	.filter(isWeekend.or(isHoliday).negate())
	.collect(Collectors.toList());
	*/
    System.out.println("680 no of days: "+days);
	System.out.println("681 no of days+1: "+(days+1));
    if(fromDate.isEqual(toDate))
    	return 1;
    else
    	return businessDays;

}

public boolean isWeekend(LocalDate date) {
	if(date.getDayOfWeek().toString().equalsIgnoreCase("SATURDAY") || date.getDayOfWeek().toString().equalsIgnoreCase("SATURDAY"))
		return true;
	else
		return false;
}




public boolean isHoliday(LocalDate date) {
	int temp = 0;
	for(Holiday holiday : holidayService.getAllHolidayList()) {
		if(holiday.getHolidayDate().isEqual(date)) {
			temp = 1;
			break;
		}
	}
	if(temp == 0)
		return false;
	else
		return true;
}

@Override
public void deleteLeavReq(int id) {
	leaveRepository.deleteById(id);
	
}

@Override
public Leave editLeavReq( Leave leavObj) {
	return leaveRepository.save(leavObj);
}



}
