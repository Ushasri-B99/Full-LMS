package com.stg.ex.serviceImplements;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stg.ex.entity.Holiday;
import com.stg.ex.exception.CustomException;
import com.stg.ex.repository.HolidaysRepository;
import com.stg.ex.service.HolidaysService;

@Service
public class HolidayServiceImpl implements HolidaysService{
	
	@Autowired(required = true)
	private HolidaysRepository holidayRepository;

	@Override
	public List<Holiday> addHolidaysList(List<Holiday> holidays) {
		return holidayRepository.saveAll(holidays);
	}

	@Override
	public void deleteAllHolidays() {
		holidayRepository.deleteAll();
	}

	
	@Override
	public String isHolidayPresent(Holiday holiday)  {
		int temp = 0;
		String msg = "";
		for(Holiday localHoliday: getAllHolidayList()) {
			if(localHoliday.getHolidayDate().isEqual(holiday.getHolidayDate()) ) {
				msg = msg + "Already this Holiday date is added " + holiday.getHolidayDate();
				temp = 1;
				break;
			}
				
			else if(localHoliday.getHolidayName().equalsIgnoreCase(holiday.getHolidayName()) ) {
				msg = msg + "Already this Holiday is added "+localHoliday.getHolidayName();
				temp = 1;
				break;
			}
		}
		if(temp == 0)
			return "false";
		else
			return msg;
		
	}

	@Override
	public Holiday addHoliday(Holiday holiday) {
		if(isHolidayPresent(holiday).equalsIgnoreCase("false"))
			return holidayRepository.save(holiday);
		else
			return holidayRepository.findByholidayName(holiday.getHolidayName());
	}

	@Override
	public void deleteHoliday(Holiday holiday) {
		holidayRepository.delete(holiday);
		
	}

	@Override
	public Optional<Holiday> getHolidayById(int id) {
		return holidayRepository.findById(id);
	}

	@Override
	public Holiday getHolidayByName(String name) {
		return holidayRepository.findByholidayName(name);
	}

	@Override
	public Holiday getByholidayDate(LocalDate date) {
		return holidayRepository.findByholidayDate(date);
	}

	@Override
	public List<Holiday> getAllHolidayList() {
		return holidayRepository.findAll();
	}

	@Override
	public Holiday updateHoliday(Holiday holiday) {
		return holidayRepository.save(holiday);
	}

}
