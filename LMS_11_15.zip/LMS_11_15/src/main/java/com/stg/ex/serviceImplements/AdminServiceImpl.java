package com.stg.ex.serviceImplements;

import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.stg.ex.dto.LeaveDto;
import com.stg.ex.dto.UserDto;
import com.stg.ex.entity.Admin;
import com.stg.ex.entity.Holiday;
import com.stg.ex.entity.Leave;
import com.stg.ex.entity.User;
import com.stg.ex.exception.CustomException;
import com.stg.ex.repository.AdminRepository;
import com.stg.ex.service.AdminService;
import com.stg.ex.service.HolidaysService;
import com.stg.ex.service.LeaveService;
import com.stg.ex.service.UserService;

@Service
public class AdminServiceImpl implements AdminService{
	
	@Autowired(required = true)
	private UserService userService;

	@Autowired(required = true)
	private HolidaysService holidaysService;
	
	@Autowired(required = true)
	private LeaveService leaveService;

	@Autowired(required = true)
	private AdminRepository adminRepository;

	@Override
	public Admin addAdmin(Admin admin) {
		return adminRepository.save(admin);
	}
	
	@Override
	public List<Admin> getAllAdmin() {
		return adminRepository.findAll();
	}
	
	@Override
	public Admin updateAdmin(Admin admin) {
		return adminRepository.save(admin);
	}

	@Override
	public void deleteAdminById(int id) {
		adminRepository.deleteById((long) id);
		
	}
	
	@Override
	public List<LeaveDto> leavesInRange(LocalDate from, LocalDate to) throws CustomException {
		return leaveService.leavesInRange(from, to);
	}

	@Override
	public List<LeaveDto> getAllLeavesByAdminDto() {
		return leaveService.getAllLeavesByAdminDto();
	}

	@Override
	public List<Leave> getAllLeavesByAdmin() {
		return leaveService.getAllLeavesByAdmin();
	}

	@Override
	public List<Holiday> getAllHolidayList() {
		return holidaysService.getAllHolidayList();
	}

	@Override
	public List<LeaveDto> getPendingLeaves() {
		return leaveService.getPendingLeaves();
	}

	@Override
	public List<LeaveDto> getApprovedLeaves() {
		return leaveService.getApprovedLeaves();
	}
	@Override
	public List<LeaveDto> getRejectedLeaves() {
		return leaveService.getRejectedLeaves();
	}
	/******************************************************************/
	
	@Override
	public List<LeaveDto> getAllLeavesByAdminIdDto(int id) {
		return leaveService.getAllLeavesByAdminDtoById( id);
	}
	
//	@Override
////	public List<Leave> getAllLeavesByAdminId(int id) {
//////		return leaveService.getAllLeavesByAdmin( id);
////	}

	@Override
	public List<LeaveDto> getPendingLeavesByAdminId(int id) {
		return leaveService.getPendingLeavesByAdminId(id);
	}

	@Override
	public List<LeaveDto> getApprovedLeavesByAdminId(int id) {
		return leaveService.getApprovedLeavesByAdminId( id);
	}
	
	@Override
	public List<LeaveDto> getRejectedLeavesByAdminId(int id) {
		return leaveService.getRejectedLeavesByAdminId( id);
	}
	
	/******************************************************************/

	
/*
	@Override
	public Leave approveLeave(Leave leave, String adminRemark) {
		return leaveService.approveLeave(leave, adminRemark);
	}
	*/
	@Override
	public Leave approveLeave(Leave leave) {
		User user = null;
		for(User localUser :  getAllUsers()) {
			if(localUser.getUserId() == leave.getUserRef().getUserId()) {
				user = localUser;
				System.out.println("102 user service : ");
				//System.out.println(localUser);
				break;
			}
		}
		return leaveService.approveLeave(leave,user);
	}
	

//	@Override
//	public Leave rejectLeave(Leave leave, String adminRemark) {
//		return leaveService.rejectLeave(leave, adminRemark);
//	}
	@Override
	public Leave rejectLeave(Leave leave) {
		return leaveService.rejectLeave(leave);
	}

	@Override
	public String isHolidayPresent(Holiday holiday)  {
		return holidaysService.isHolidayPresent(holiday);
	}

	@Override
	public List<Holiday> addHolidaysList(List<Holiday> holidays) {
		return holidaysService.addHolidaysList(holidays);
	}

	@Override
	public void deleteAllHolidays() {
		holidaysService.deleteAllHolidays();
	}

	@Override
	public User createUser(User user) {
		return userService.createUser(user);
	}

	@Override
	public User updateUser(User user) {
		return userService.updateUser(user);
	}

	@Override
	public void deleteUserById(int id) {
		userService.deleteUserById(id);
	}

	@Override
	public List<User> getAllUsers() {
		return userService.getAllUsers();
	}

	@Override
	public List<UserDto> getAllUsersDto() {
		return userService.getAllUsersDto();
	}
	@Override
	public List<User> getAllUsersByAdminId(int id) throws CustomException {
		return userService.getAllUsersByAdminId(id);
	}

	@Override
	public List<UserDto> getAllUsersDtoByAdminId(int id) throws CustomException{
		return userService.getAllUsersDtoByAdminId(id);
	}

	@Override
	public Admin adminLogin(int id, String pswd) {		
		return null;
	}

	@Override
	public Holiday addHoliday(Holiday holiday) {
		return holidaysService.addHoliday(holiday);
	}

	@Override
	public Holiday updateHoliday(Holiday holiday) {
		return holidaysService.updateHoliday(holiday);
	}
	
	

	
	
	/*
	@Override
	public User createUser(User user) {
		return userRepository.save(user);
	}

	@Override
	public User updateUser(User user) {
		return userRepository.save(user);
	}

	@Override
	public void deleteUserById(int id) {
		userRepository.deleteById(id);
	}

	@Override
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	@Override
	public List<UserDto> getAllUsers1() {
		List<UserDto> userlist = new ArrayList<UserDto>();
		for(User user : userRepository.findAll()) {
			UserDto userdto = new UserDto();

			userdto.setUserId(user.getUserId());
			userdto.setFirstName(user.getFirstName());
			userdto.setLastName(user.getLastName());
			userdto.setGender(user.getGender());
			userdto.setEmail(user.getEmail());
			userdto.setRole(user.getRole());
			userdto.setPhoneNumber(user.getPhoneNumber());

			userdto.setLeave_bal(user.getLeave_bal());
			userdto.setLeavesList(user.getLeavesList());
			userdto.setAdminId(user.getAdminRef().getAdmin_id());
			userdto.setAdminName(user.getAdminRef().getName());

			userlist.add(userdto);

		}
		return userlist;
	}

	@Override
	public List<Leave> getAllLeavesByAdmin() {
		return leaveRepository.findAll();
	}

	@Override
	public List<LeaveDto> getAllLeavesByAdmin1() {
		List<LeaveDto> leaveDtoList = new ArrayList<LeaveDto>();
		for(Leave leave : leaveRepository.findAll()) {
			LeaveDto leavedto = new LeaveDto();

			leavedto.setLeaveId(leave.getLeaveId());
			leavedto.setLeaveReason(leave.getLeaveReason());
			leavedto.setFromDate(leave.getFromDate());
			leavedto.setToDate(leave.getToDate());
			leavedto.setCreatedAt(leave.getCreatedAt());
			leavedto.setAdminRemark(leave.getAdminRemark());
			leavedto.setStatus(leave.getStatus());
			leavedto.setLeaveType(leave.getLeaveType());
			leavedto.setNoOfDays(leave.getNoOfDays());
			leavedto.setLop(leave.getLop());
			leavedto.setUserId(leave.getUserRef().getUserId());
			leavedto.setUsername(leave.getUserRef().getFirstName()+" "+leave.getUserRef().getLastName());

			leaveDtoList.add(leavedto);
		}
		return leaveDtoList;
	}

	@Override
	public List<Leave> getPendingLeaves() {
		return leaveRepository.findAll().stream().filter(p -> p.getStatus() == LeaveStatus.PENDING).collect(Collectors.toList());

	}

	@Override
	public List<Leave> getApprovedLeaves() {
		return leaveRepository.findAll().stream().filter(p -> p.getStatus() == LeaveStatus.ACCEPTED).collect(Collectors.toList());

	}

	@Override
	public List<Leave> getRejectedLeaves() {
		return leaveRepository.findAll()
				.stream()
				.filter(p -> p.getStatus() == LeaveStatus.REJECTED).collect(Collectors.toList());
	}

	@Override
	public Leave approveLeave(Leave leave, String adminRemark) {
		leave.setStatus(LeaveStatus.ACCEPTED);
		leave.setAdminRemark(adminRemark);
		if(leave.getLeaveType() == LeaveType.HALF_DAY_LEAVE) {
			return halfDayLeave(leave);
		}
		else {
			long noOfLeaves = noOfLeaves(leave.getFromDate(),leave.getToDate())+1;
			//leave.setNoOfDays(noOfLeaves);

			if(leave.getLeaveType() == LeaveType.MATERNITY_LEAVE) {
				return maternityLeave(leave,noOfLeaves);
			}
			else if(leave.getLeaveType() == LeaveType.PATERNITY_LEAVE) {
				return paternityLeave(leave,noOfLeaves);
			}

			else {
				return othersLeave(leave, noOfLeaves);
			}
		}
	}

	@Override
	public Leave rejectLeave(Leave leave, String adminRemark) {
		leave.setStatus(LeaveStatus.REJECTED);
		leave.setAdminRemark(adminRemark);
		leave.setLop(0);
		leaveRepository.save(leave);
		return leave;
	}

	@Override
	public List<Holiday> addHolidaysList(List<Holiday> holidays) {
		return holidayRepository.saveAll(holidays);
	}

	@Override
	public void deleteAllHolidays() {
		holidayRepository.deleteAll();
	}

	public Leave maternityLeave(Leave leave, long noOfLeaves) {
		if(noOfLeaves > Constants.MATERNITY_LEAVES) {
			long remaining_days = noOfLeaves - Constants.MATERNITY_LEAVES;
			if(leave.getUserRef().getLeave_bal() > 0) {
				if(leave.getUserRef().getLeave_bal() - remaining_days >= 0) {
					leave.getUserRef().setLeave_bal(leave.getUserRef().getLeave_bal() - remaining_days);
				}
				else {
					leave.setLop(Math.abs(leave.getUserRef().getLeave_bal() - remaining_days));
					leave.getUserRef().setLeave_bal(0);
				}
			}
			else {
				leave.setLop(Math.abs(remaining_days));
				leave.getUserRef().setLeave_bal(0);
			}

		}
		userService.updateUser(leave.getUserRef());
		leaveRepository.save(leave);
		return leave;
	}

	public Leave paternityLeave(Leave leave, long noOfLeaves) {
		if(noOfLeaves > Constants.PATERNITY_LEAVES) {
			long remaining_days = noOfLeaves - Constants.PATERNITY_LEAVES;
			if(leave.getUserRef().getLeave_bal() > 0) {
				if(leave.getUserRef().getLeave_bal() - remaining_days >= 0) {
					leave.getUserRef().setLeave_bal(leave.getUserRef().getLeave_bal() - remaining_days);
				}
				else {
					leave.setLop(remaining_days - leave.getUserRef().getLeave_bal() );
					leave.getUserRef().setLeave_bal(0);
				}
			}
			else {
				leave.setLop(Math.abs(remaining_days));
				leave.getUserRef().setLeave_bal(0);
			}

		}
		userService.updateUser(leave.getUserRef());
		leaveRepository.save(leave);
		return leave;
	}

	public Leave othersLeave(Leave leave, long noOfLeaves) {
		if(leave.getUserRef().getLeave_bal() > 0) {
			if(leave.getUserRef().getLeave_bal() - noOfLeaves >= 0) {
				leave.getUserRef().setLeave_bal(leave.getUserRef().getLeave_bal() - noOfLeaves);
			}
			else {
				leave.setLop(Math.abs(leave.getUserRef().getLeave_bal() - noOfLeaves));
				leave.getUserRef().setLeave_bal(0);
			}
		}
		else {
			leave.setLop(Math.abs(noOfLeaves));
			leave.getUserRef().setLeave_bal(0);
		}
		userService.updateUser(leave.getUserRef());
		leaveRepository.save(leave);
		return leave;
	}

	public Leave halfDayLeave(Leave leave) {
		leave.setNoOfDays(0.5);
		if(leave.getUserRef().getLeave_bal() > 0) 
			leave.getUserRef().setLeave_bal(leave.getUserRef().getLeave_bal()-0.5);
		else
			leave.setLop(0.5);
		userService.updateUser(leave.getUserRef());
		leaveRepository.save(leave);
		return leave;
	}

	public long noOfLeaves(LocalDate fromDate, LocalDate toDate) {
		Set<DayOfWeek> weekend = EnumSet.of(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY);
		final long weekDaysBetween = fromDate.datesUntil(toDate)
				.filter(d -> !weekend.contains(d.getDayOfWeek()))
				.count();
		return weekDaysBetween;

	}

	public boolean isHoliday(LocalDate date) {
		int temp = 0;
		for(Holiday holiday : holidayRepository.findAll()) {
			if(holiday.getHolidayDate().isEqual(date)) {
				temp = 1;
				break;
			}
		}
		if(temp == 0)
			return false;
		else
			return true;
	}


	@Override
	public List<Holiday> getAllHolidayList() {
		return holidayRepository.findAll();
	}

	@Override
	public List<LeaveDto> leavesInRange(LocalDate from, LocalDate to) {
		List<LeaveDto> leaveList = new ArrayList<LeaveDto>();
		for(LeaveDto leave : getAllLeavesByAdmin1()) {
			if(leave.getFromDate().isEqual(from) || isWithinRange(leave.getFromDate(),from, to) 
					|| (leave.getFromDate().isEqual(to)) || (leave.getToDate().isEqual(from))
					|| (isWithinRange(leave.getToDate(),from, to)) || (leave.getToDate().isEqual(to)) ){
				leaveList.add(leave);
				//System.out.println("leave.getFromDate().isEqual(from) " + leave.getLeaveId());
			}
			/*
			else if(isWithinRange(leave.getFromDate(),from, to)) {
				//System.out.println("isWithinRange(leave.getFromDate(),from, to) " + leave.getLeaveId());
				leaveList.add(leave);
			}
			else if(leave.getFromDate().isEqual(to)) {
				//System.out.println("leave.getFromDate().isEqual(to) " + leave.getLeaveId());
				leaveList.add(leave);
			}
			else  if(leave.getToDate().isEqual(from)){
				leaveList.add(leave);
				//System.out.println("leave.getToDate().isEqual(from) " + leave.getLeaveId());
			}
			else if(isWithinRange(leave.getToDate(),from, to)) {
				//System.out.println("isWithinRange(leave.getToDate(),from, to) " + leave.getLeaveId());
				leaveList.add(leave);
			}
			else if(leave.getToDate().isEqual(to)) {
				//System.out.println("leave.getToDate().isEqual(to) " + leave.getLeaveId());
				leaveList.add(leave);
			}
			***********
		}
		return leaveList;
	}

	public boolean isWithinRange(LocalDate testDate,LocalDate from, LocalDate to) {
		return (testDate.isAfter(from)) &&( testDate.isBefore(to) );
	}

	@Override
	public boolean isHolidayPresent(Holiday holiday) throws CustomException {
		for(Holiday localHoliday: getAllHolidayList()) {
			if(localHoliday.getHolidayDate() == holiday.getHolidayDate())
				throw new CustomException("Already this Holiday date is added " + holiday.getHolidayDate());
			else if(localHoliday.getHolidayName() == holiday.getHolidayName())
				throw new CustomException("Already this Holiday is added "+localHoliday.getHolidayName());
		}
		return false;
	}
*/

	

}
