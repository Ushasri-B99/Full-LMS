package com.stg.ex.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stg.ex.entity.Admin;
@Repository
public interface AdminRepository extends JpaRepository<Admin, Long>{

}
