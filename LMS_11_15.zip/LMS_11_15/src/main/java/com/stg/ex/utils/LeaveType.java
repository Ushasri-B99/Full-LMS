package com.stg.ex.utils;

public enum LeaveType {
	SICK_lEAVE,
	HALF_DAY_LEAVE,
	CASUAL_LEAVE,
	MATERNITY_LEAVE,
	PATERNITY_LEAVE,
	OTHERS

}
