package com.stg.ex.entity;

import java.util.List;

import javax.persistence.*;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="user_tab")
public class User {
	@Id
	@Column(name = "user_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int userId;	
	
	@Column(name = "emp_id",unique = true)
	private String empId;
	
	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "gender")
	private String gender;

	@Column(name = "email",unique = true)
	private String email;

	@Column(name = "password")
	private String password = "Reset@123";

	@Column(name = "role", nullable = false)
	private String role;


	@Column(name = "phone_number", nullable = false)
	private String phoneNumber;

	//private int total_leaves;
	private double leave_bal;

	@JsonManagedReference
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "userRef") // cascade means if teacher is deleted related students should be delete
	private List<Leave> leavesList;

	@ManyToOne
	@JoinColumn(name = "admin_id", nullable = false)
	@JsonBackReference
	private Admin adminRef;

}
