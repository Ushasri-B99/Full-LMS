package com.stg.ex.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.stg.ex.utils.LeaveStatus;
import com.stg.ex.utils.LeaveType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LeaveDto {
	private int userId;
	private String username;
	private int leaveId;
	private String leaveReason;
	private LocalDate fromDate;
	private LocalDate toDate;
	private LocalDateTime createdAt;
	private String adminRemark;
	private LeaveStatus status;
	private LeaveType leaveType;
	private double noOfDays;	
	private double lop;
}	
