package com.stg.ex.dto;

import java.time.LocalDate;
import com.stg.ex.utils.LeaveType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApplyLeaveDto {
	private String leaveReason;
	private LocalDate fromDate;
	private LocalDate toDate;
	private LeaveType leaveType ;
	private int userId;
}
