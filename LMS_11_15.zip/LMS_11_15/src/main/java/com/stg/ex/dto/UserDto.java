package com.stg.ex.dto;

import java.util.List;

import com.stg.ex.entity.Leave;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {
	
	private int userId;
	//userId firstName lastName  gender email role phoneNumber leave_bal adminId adminName leavesList
	private String firstName;

	private String lastName;

	private String gender;

	private String email;
	

	//private String password;

	private String role;

	private String phoneNumber;

	//private int total_leaves;
	
	private double leave_bal;

	private List<Leave> leavesList;
	
	private int adminId;

	private String  adminName ;
	
	private String empId;

}
