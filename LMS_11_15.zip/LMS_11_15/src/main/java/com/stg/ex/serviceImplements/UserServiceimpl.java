package com.stg.ex.serviceImplements;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.stg.ex.dto.LeaveDto;
import com.stg.ex.dto.LoginCredentials;
import com.stg.ex.dto.UserDto;
import com.stg.ex.entity.Holiday;
import com.stg.ex.entity.Leave;
import com.stg.ex.entity.Password;
import com.stg.ex.entity.User;
import com.stg.ex.exception.CustomException;
import com.stg.ex.repository.UserRepository;
import com.stg.ex.service.HolidaysService;
import com.stg.ex.service.LeaveService;
import com.stg.ex.service.UserService;
import com.stg.ex.utils.LeaveStatus;
import com.stg.ex.utils.LeaveType;

@Service
public class UserServiceimpl implements UserService{

	@Autowired(required=true)
	private LeaveService leaveService;

	@Autowired(required = true)
	private UserRepository userRepository;
	
	@Autowired(required = true)
	private HolidaysService holidaysService;
	
	@Override
	public User createUser(User user) {
		return userRepository.save(user);
	}

	@Override
	public User updateUser(User user) {
		return userRepository.save(user);
	}

	@Override
	public void deleteUserById(int id) {
		userRepository.deleteById(id);
	}

	@Override
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	@Override
	public List<UserDto> getAllUsersDto() {
		List<UserDto> userlist = new ArrayList<UserDto>();
		for(User user : userRepository.findAll()) {
			UserDto userdto = new UserDto();

			userdto.setUserId(user.getUserId());
			userdto.setFirstName(user.getFirstName());
			userdto.setLastName(user.getLastName());
			userdto.setGender(user.getGender());
			userdto.setEmail(user.getEmail());
			userdto.setRole(user.getRole());
			userdto.setPhoneNumber(user.getPhoneNumber());
			userdto.setEmpId(user.getEmpId());
			userdto.setLeave_bal(user.getLeave_bal());
			userdto.setLeavesList(user.getLeavesList());
			userdto.setAdminId(user.getAdminRef().getAdmin_id());
			userdto.setAdminName(user.getAdminRef().getName());
			userdto.setEmpId(user.getEmpId());
			

			userlist.add(userdto);

		}
		return userlist;
	}
	/**
	 * @throws CustomException *************************************************************************/
	@Override
	public List<User> getAllUsersByAdminId(int id) throws CustomException {
		List<User> userList = new ArrayList<User>();
		if(userRepository.findAll().size() != 0) {
			for(User user : userRepository.findAll()) {
				if(user.getAdminRef().getAdmin_id() == id) {
					System.out.println("93 userserviceimple: "+user.getAdminRef().getAdmin_id());
					userList.add(user);				}
			}
			System.out.println("UserList 95 : ");
			//System.out.println(userList);
			return userList;
		}
		else 
			throw new CustomException("No users under this admin Id: "+ id);
		
		//return userRepository.findAll();
	}

	@Override
	public List<UserDto> getAllUsersDtoByAdminId(int id) throws CustomException{
		List<UserDto> userlist = new ArrayList<UserDto>();
		if(userRepository.findAll().size() != 0) {
			for(User user : userRepository.findAll()) {
				if(user.getAdminRef().getAdmin_id() == id) {
					
					UserDto userdto = new UserDto();
					userdto.setUserId(user.getUserId());
					userdto.setFirstName(user.getFirstName());
					userdto.setLastName(user.getLastName());
					userdto.setGender(user.getGender());
					userdto.setEmail(user.getEmail());
					userdto.setRole(user.getRole());
					userdto.setPhoneNumber(user.getPhoneNumber());
					userdto.setEmpId(user.getEmpId());
					userdto.setLeave_bal(user.getLeave_bal());
					userdto.setLeavesList(user.getLeavesList());
					userdto.setAdminId(user.getAdminRef().getAdmin_id());
					userdto.setAdminName(user.getAdminRef().getName());
					userdto.setEmpId(user.getEmpId());
					
					userlist.add(userdto);
				}			
			}
			return userlist;
		}
		else 
			throw new CustomException("No users under this admin Id: "+ id);
		
		
	}
	/************************************************************************/

	@Override
	public User getUserDetails(int id) {
		return userRepository.findByUserId(id);
	}

	@Override
	public List<Leave> getUserLeavesList(int userId) {
		List<Leave> leaves = leaveService.getAllLeavesByAdmin();
		List<Leave>userLeaveList = leaves.stream().filter(p->p.getUserRef().getUserId() == userId).collect(Collectors.toList());
		return userLeaveList;
	}
/*
	@Override
	public Leave applyLeave(Leave leave) throws CustomException {
		
		if(isHoliday(leave.getFromDate()))				
			throw new CustomException("From-Date that you have entered is Holiday");
		else if(isHoliday(leave.getToDate()))
			throw new CustomException("To-Date that you have entered is Holiday");
		if(leave.getLeaveType() == LeaveType.HALF_DAY_LEAVE) {
			if(!leave.getFromDate().isEqual(leave.getToDate())) {
				throw new CustomException("While applying half day leave from-date and to-date must be same");
			}
		}
		
		User user = null;
		System.out.println("97 userservice: user obj "+leave.getUserRef());
		for(User localUser :  userRepository.findAll()) {
			
			if(localUser.getUserId() == leave.getUserRef().getUserId()) {
				user = localUser;
				System.out.println("102 user service : ");
				//System.out.println(localUser);
				break;
			}
		}
		return leaveService.applyLeave(leave,user);
	}
	*/
//	public List<Leave> getLeavesByUserId1(@PathVariable int userId){
//		return userService.getUserLeavesList(userId);
//	}
	@Override
	public Leave applyLeave(Leave leave) throws CustomException {

		if(isHoliday(leave.getFromDate()))				
			throw new CustomException("From-Date that you have entered is Holiday");
		else if(isHoliday(leave.getToDate()))
			throw new CustomException("To-Date that you have entered is Holiday");
		if(leave.getLeaveType() == LeaveType.HALF_DAY_LEAVE) {
			if(!leave.getFromDate().isEqual(leave.getToDate())) {
				throw new CustomException("While applying half day leave from-date and to-date must be same");
			}
		}

		User user = null;
		System.out.println("97 userservice: user obj "+leave.getUserRef());
		for(User localUser :  userRepository.findAll()) {

			if(localUser.getUserId() == leave.getUserRef().getUserId()) {
				user = localUser;
				System.out.println("102 user service : ");
				//System.out.println(localUser);
				break;
			}
		}
		return leaveService.applyLeave(leave,user);
	}
	
	
public boolean isWithinRange(LocalDate testDate,LocalDate from, LocalDate to) {
	return (testDate.isAfter(from)) &&( testDate.isBefore(to) );
}

	public boolean isHoliday(LocalDate date) {
		int temp = 0;
		for(Holiday holiday : holidaysService.getAllHolidayList()) {
			if(holiday.getHolidayDate().isEqual(date)) {
				temp = 1;
				break;
			}
		}
		if(temp == 0)
			return false;
		else
			return true;
	}

	@Override
	public String login1(String empId,String pswd) {
		int id =0;
		for(User user : userRepository.findAll()) {
//			if(user.getEmpId() == login.getEmpId() && user.getPassword() == login.getPassword()) {
//				user1 = user;
//				temp = 1;
//				break;
//			}
			if(user.getEmpId().equals(empId)) {
				if(user.getPassword().equals(pswd)) {
					id = 2;
					break;
					//return "login Success";
				}
				else {
					id=1;
					break;
					//return "Wrong Password";
				}
			}
			
		}
		if(id == 0) {
			
			return "There is no employee with that Id";
		}
		else if(id == 1) {
			return "Wrong Password";
		}
		else if(id == 2) {
			return "login Success";
		}
		return null;	
	}
	
	@Override
	public User login(String empId,String pswd) {
		User user1 = null;
		int id =0;
		for(User user : userRepository.findAll()) {
//			if(user.getEmpId() == login.getEmpId() && user.getPassword() == login.getPassword()) {
//				user1 = user;
//				temp = 1;
//				break;
//			}
			if(user.getEmpId().equals(empId)) {
				if(user.getPassword().equals(pswd)) {
					user1 = user;
					id = 2;
					break;
					//return "login Success";
				}
				else {
					id=1;
					break;
					//return "Wrong Password";
				}
			}
			
		}
		return user1;
	}

	@Override
	public User updatePswd1(int userId, String oldPswd, String newPasword ) {
		User user1 = null;
		for(User user : userRepository.findAll()) {
			if(user.getUserId() == userId) {
				if(user.getPassword().equalsIgnoreCase(oldPswd)) {
					user.setPassword(newPasword);
					user1 = user;
				}
			}
		}
		return user1;
	}
	@Override
	public User updatePswd(Password obj ) throws CustomException {
		User user1 = null;
		for(User user : userRepository.findAll()) {
			if(user.getUserId() == obj.getUserId()) {
				if(user.getPassword().equalsIgnoreCase(obj.getOldPswd())) {
					user.setPassword(obj.getNewPswd());
					user1 = user;
					userRepository.save(user);
				}
				else
					throw new CustomException("Wrong Password");
				
			}
		}
		return user1;
	}

	@Override
	public List<LeaveDto> getUserLeavesListDto(int userId) {
		return leaveService.getAllLeavesByUserDto(userId);
	
	}

	@Override
	public List<Holiday> getAllHolidayList() {
		return holidaysService.getAllHolidayList();
	}

	@Override
	public List<LeaveDto> getPendingLeavesById(int id) {
		return leaveService.getPendingLeavesById(id);
	}

	@Override
	public List<LeaveDto> getApprovedLeavesById(int id) {
		return leaveService.getApprovedLeavesById(id);
	}

	@Override
	public List<LeaveDto> getRejectedLeavesById(int id) {
		return leaveService.getRejectedLeavesById(id);
	}

	@Override
	public void deleteLeavReq(int id) {
		leaveService.deleteLeavReq(id);
		
	}

	@Override
	public Leave editLeavReq(Leave leavObj) {
		return leaveService.editLeavReq(leavObj);
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
/*
	@Override
	public Leave applyLeave(Leave leave) throws CustomException {
		if(LocalDate.now().isAfter(leave.getFromDate()))
			throw new CustomException("From date must be After or equal to Today");
		if(leave.getFromDate().isAfter(leave.getToDate()))
			throw new CustomException("From date must be before to To-Date");
		else {
			if(isHoliday(leave.getFromDate()))
				throw new CustomException("From-Date that you have entered is Holiday");

			else if(isHoliday(leave.getToDate()))
				throw new CustomException("To-Date that you have entered is Holiday");

			else if(leave.getFromDate().getDayOfWeek().toString().equalsIgnoreCase("SATURDAY"))
				throw new CustomException("From-Date that you have entered is SATURDAY");

			else if(leave.getFromDate().getDayOfWeek().toString().equalsIgnoreCase("SUNDAY"))
				throw new CustomException("From-Date that you have entered is SUNDAY");

			if(leave.getToDate().getDayOfWeek().toString().equalsIgnoreCase("SATURDAY"))
				throw new CustomException("To-Date that you have entered is SATURDAY");

			else if(leave.getToDate().getDayOfWeek().toString().equalsIgnoreCase("SUNDAY"))
				throw new CustomException("To-Date that you have entered is SUNDAY");
			else{
				if(leave.getLeaveType() == LeaveType.HALF_DAY_LEAVE) {
					if(leave.getFromDate().isEqual(leave.getToDate())) {
						leave.setNoOfDays(0.5);
						leave.setLop(lop(leave));
						return leaveRepo.save(leave);
					}
					else
						throw new CustomException("While applying HALF_DAY_LEAVE from-date and to-date must be same");
				}
				else {
					if(leave.getLeaveType() == LeaveType.MATERNITY_LEAVE || leave.getLeaveType() == LeaveType.PATERNITY_LEAVE) {
						leave.setNoOfDays(ChronoUnit.DAYS.between(leave.getFromDate(), leave.getToDate())+1);
					}
					else
						leave.setNoOfDays(noOfLeaves(leave.getFromDate(),leave.getToDate())+1);
					leave.setLop(lop(leave));
				}
				return leaveRepo.save(leave);
			}
		}
	}
	public double lop(Leave leave) {

		long noOfLeaves = ChronoUnit.DAYS.between(leave.getFromDate(), leave.getToDate())+1;
		System.out.println("noOfLeaves : " + noOfLeaves);
		if(leave.getLeaveType() == LeaveType.MATERNITY_LEAVE ) {
			if(noOfLeaves > Constants.MATERNITY_LEAVES) {
				long remaining_days = noOfLeaves - Constants.MATERNITY_LEAVES;
				if(leave.getUserRef().getLeave_bal() > 0) {
					if(leave.getUserRef().getLeave_bal() - remaining_days >= 0) {
						return 0;
						//leave.setLop(0);
					}
					else {
						//leave.setLop(Math.abs(leave.getUserRef().getLeave_bal() - remaining_days));
						return Math.abs(leave.getUserRef().getLeave_bal() - remaining_days);
					}
				}
				else {
					//leave.setLop(Math.abs(remaining_days));
					System.out.println("remaining days : " + remaining_days);
					return remaining_days;
				} 
			}
			else
				return 0;
		}
		else if(leave.getLeaveType() == LeaveType.PATERNITY_LEAVE ) {
			if(noOfLeaves > Constants.PATERNITY_LEAVES) {
				long remaining_days = noOfLeaves - Constants.PATERNITY_LEAVES;
				if(leave.getUserRef().getLeave_bal() > 0) {
					if(leave.getUserRef().getLeave_bal() - remaining_days >= 0) {
						return 0;
						//leave.setLop(0);
					}
					else {
						//leave.setLop(Math.abs(leave.getUserRef().getLeave_bal() - remaining_days));
						return Math.abs(leave.getUserRef().getLeave_bal() - remaining_days);
					}
				}
				else {
					//leave.setLop(Math.abs(remaining_days));
					return remaining_days;
				} 
			}
			else
				return 0;
		}
		else {
			Long totalDays = noOfLeaves(leave.getFromDate(), leave.getToDate());
			if(leave.getUserRef().getLeave_bal() > 0) {
				if(leave.getUserRef().getLeave_bal() - totalDays >= 0) {
					return 0;
					//leave.setLop(0);
				}
				else {
					//leave.setLop(Math.abs(leave.getUserRef().getLeave_bal() - remaining_days));
					return Math.abs(totalDays - leave.getUserRef().getLeave_bal() );
				}
			}
			else {
				System.out.println("other total days : " + totalDays);
				return totalDays;
				
			}
		}
			
	}
	
	/*
		 if(noOfLeaves > Constants.MATERNITY_LEAVES) {
			long remaining_days = noOfLeaves - Constants.MATERNITY_LEAVES;
			if(leave.getUserRef().getLeave_bal() > 0) {
				if(leave.getUserRef().getLeave_bal() - remaining_days >= 0) {
					leave.getUserRef().setLeave_bal(leave.getUserRef().getLeave_bal() - remaining_days);
				}
				else {
					leave.setLop(Math.abs(leave.getUserRef().getLeave_bal() - remaining_days));
					leave.getUserRef().setLeave_bal(0);
				}
			}
			else {
				leave.setLop(Math.abs(remaining_days));
				leave.getUserRef().setLeave_bal(0);
			} 

	 */

/*
		if(leave.getLeaveType() == LeaveType.HALF_DAY_LEAVE)
			leave.setNoOfDays(0.5);
		else
			leave.setNoOfDays(noOfLeaves(leave.getFromDate(),leave.getToDate())+1);
		return leaveRepo.save(leave);
 ****************************************** last comment

public long noOfLeaves(LocalDate fromDate, LocalDate toDate) {
	Set<DayOfWeek> weekend = EnumSet.of(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY);
	final long weekDaysBetween = fromDate.datesUntil(toDate)
			.filter(d -> (!(weekend.contains(d.getDayOfWeek())) && (isHoliday(d))))
			.count();
	
	return weekDaysBetween;
	

}
	public boolean isHoliday(LocalDate date) {
		int temp = 0;
		for(Holiday holiday : holidayRepo.findAll()) {
			if(holiday.getHolidayDate().isEqual(date)) {
				temp = 1;
				break;
			}
		}
		if(temp == 0)
			return false;
		else
			return true;
	}
*/


}
