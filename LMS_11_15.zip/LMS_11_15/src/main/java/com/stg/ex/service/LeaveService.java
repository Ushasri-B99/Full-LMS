package com.stg.ex.service;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.stg.ex.dto.LeaveDto;
import com.stg.ex.entity.Leave;
import com.stg.ex.entity.User;
import com.stg.ex.exception.CustomException;

public interface LeaveService {
	
	public Leave applyLeave(Leave leave,User user) throws CustomException ;

	public abstract List<LeaveDto> leavesInRange( LocalDate from, LocalDate to) throws CustomException;

	public abstract List<LeaveDto> getAllLeavesByAdminDto();

	public abstract List<Leave> getAllLeavesByAdmin();

	//public abstract List<Holiday> getAllHolidayList();

	public abstract List<LeaveDto> getPendingLeaves();

	public abstract List<LeaveDto> getApprovedLeaves();

	public abstract List<LeaveDto> getRejectedLeaves();

	//public abstract Leave approveLeave(Leave leave, String adminRemark);
	public abstract Leave approveLeave(Leave leave,User user);
	
	public abstract Leave approveLeave1(Leave leave);

	//public abstract Leave rejectLeave(Leave leave, String adminRemark);
	public abstract Leave rejectLeave(Leave leave);

	public abstract Optional<Leave> getLeaveById(int id) ;

	List<LeaveDto> getAllLeavesByUserDto(int id);

	List<LeaveDto> getPendingLeavesById(int id);
	
	public abstract void deleteLeavReq(int id);
	
	public abstract Leave editLeavReq(Leave leavObj);
	

	List<LeaveDto> getApprovedLeavesById(int id);

	List<LeaveDto> getRejectedLeavesById(int id);

	/********************************************************************************************/
//	List<Leave> getAllLeavesByAdminId(int id);
	List<LeaveDto> getPendingLeavesByAdminId(int id);

	List<LeaveDto> getApprovedLeavesByAdminId(int id);

	List<LeaveDto> getAllLeavesByAdminDtoById(int id);

	List<LeaveDto> getRejectedLeavesByAdminId(int id);
}
