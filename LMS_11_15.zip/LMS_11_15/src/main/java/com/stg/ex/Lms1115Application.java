package com.stg.ex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.SwaggerDefinition;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@RestController
@SwaggerDefinition
public class Lms1115Application {

	public static void main(String[] args) {
		SpringApplication.run(Lms1115Application.class, args);
	}

}
