package com.stg.ex.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.stg.ex.entity.Holiday;

public interface HolidaysService {

	public abstract String isHolidayPresent(Holiday holiday) ;

	public abstract List<Holiday> addHolidaysList(List<Holiday> holidays) ;

	public abstract Holiday addHoliday(Holiday holiday) ;
	
	public abstract Holiday updateHoliday(Holiday holiday) ;
	
	public abstract void deleteHoliday(Holiday holidays);

	public abstract void deleteAllHolidays();
	
	public abstract Optional<Holiday> getHolidayById(int id);
	
	public abstract Holiday getHolidayByName(String name);
	
	public abstract Holiday getByholidayDate(LocalDate date);
	
	public abstract List<Holiday> getAllHolidayList();
	
}
