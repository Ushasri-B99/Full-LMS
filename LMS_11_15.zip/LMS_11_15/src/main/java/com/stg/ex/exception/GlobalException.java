package com.stg.ex.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;


@RestControllerAdvice
public class GlobalException {
	@ExceptionHandler(ApplyingLeaveOnHoliday.class)
    public ResponseEntity<ErrorDetails> handleEmployeeNotFoundException(ApplyingLeaveOnHoliday leaveOnHoliday, WebRequest webRequest){
        ErrorDetails errorDetails = new ErrorDetails(new Date(),leaveOnHoliday.getMessage(),webRequest.getDescription(false),HttpStatus.NOT_ACCEPTABLE.toString());
        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
    }
	
	@ExceptionHandler(CustomException.class)
    public ResponseEntity<ErrorDetails> dataNotFoundException(CustomException customException, WebRequest webRequest){
        ErrorDetails errorDetails = new ErrorDetails(new Date(),customException.getMessage(),webRequest.getDescription(false),HttpStatus.NOT_ACCEPTABLE.toString());
        System.out.println("Error in java: "+customException.getMessage());
        return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
