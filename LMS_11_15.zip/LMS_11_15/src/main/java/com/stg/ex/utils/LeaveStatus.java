package com.stg.ex.utils;

public enum LeaveStatus {
	PENDING, ACCEPTED, REJECTED
}
