package com.stg.ex.repository;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stg.ex.entity.Holiday;

@Repository
public interface HolidaysRepository extends JpaRepository<Holiday, Integer>{
	
	public abstract Holiday findByholidayName(String name);
	
	public abstract Holiday findByholidayDate(LocalDate date);
}
