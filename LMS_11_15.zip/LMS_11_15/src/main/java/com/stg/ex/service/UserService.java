package com.stg.ex.service;

import java.util.List;

import com.stg.ex.dto.LeaveDto;
import com.stg.ex.dto.LoginCredentials;
import com.stg.ex.dto.UserDto;
import com.stg.ex.entity.Holiday;
import com.stg.ex.entity.Leave;
import com.stg.ex.entity.Password;
import com.stg.ex.entity.User;
import com.stg.ex.exception.CustomException;

public interface UserService {
	
	public abstract User createUser(User user);

	//public abstract String login(LoginCredentials login);
	
	public abstract String login1(String id, String pswd);
	
	public abstract User login(String id, String pswd);

	
	public abstract User updatePswd1(int userId,String oldPswd, String newPasword);
	
	public abstract User updatePswd(Password pswdObj) throws CustomException;
	
	
	public abstract User updateUser(User user);
	
	public abstract void deleteUserById(int id);
	
	public abstract List<User> getAllUsers();
	
	public abstract List<UserDto> getAllUsersDto();
		
	public abstract User getUserDetails(int id);
	
	public abstract Leave applyLeave(Leave leave) throws CustomException;
	
	public abstract List<Leave> getUserLeavesList(int userId);
	
	public abstract List<LeaveDto> getUserLeavesListDto(int userId);
	
	public abstract List<Holiday> getAllHolidayList();
	
	public abstract List<LeaveDto> getPendingLeavesById(int id);
	
	public abstract List<LeaveDto> getApprovedLeavesById(int id);
	
	public abstract List<LeaveDto> getRejectedLeavesById(int id);
	
	public abstract void deleteLeavReq(int id);
	
	public abstract Leave editLeavReq(Leave leavObj);

	List<User> getAllUsersByAdminId(int id) throws CustomException;

	List<UserDto> getAllUsersDtoByAdminId(int id) throws CustomException;

	//public abstract String userLogin(int userId, String email, String password);
}
