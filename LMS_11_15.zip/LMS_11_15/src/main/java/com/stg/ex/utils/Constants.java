package com.stg.ex.utils;

public class Constants {
	public static final long MATERNITY_LEAVES = 120;
	public static final long PATERNITY_LEAVES = 30;
}
