package com.stg.ex.exception;

public class ApplyingLeaveOnHoliday extends Exception {
	private static final long serialVersionUID = 1L;
	private String errMsg;
	
	public ApplyingLeaveOnHoliday(String errMsg) {
		super();
		this.errMsg = errMsg;
	}
	
	@Override
	public String getMessage() {
		return this.errMsg;
	}
}
