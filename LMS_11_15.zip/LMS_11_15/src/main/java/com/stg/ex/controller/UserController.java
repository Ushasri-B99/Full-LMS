package com.stg.ex.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stg.ex.dto.LeaveDto;
import com.stg.ex.dto.LoginCredentials;
import com.stg.ex.entity.Leave;
import com.stg.ex.entity.Password;
import com.stg.ex.entity.User;
import com.stg.ex.exception.CustomException;
import com.stg.ex.service.LeaveService;
import com.stg.ex.service.UserService;
import com.stg.ex.utils.LeaveStatus;

@RestController
@RequestMapping(value="user")
@CrossOrigin("http://localhost:4200/")
public class UserController {
	
	@Autowired
	private UserService userService;
	/*
	@PostMapping(value="/applyLeave")
	public Leave applyLeave(@RequestBody Leave leave) throws CustomException {
		if(leave != null) {
			return userService.applyLeave(leave);
		}
		else
			throw new CustomException("Please Enter Leave Details");
	}
	*/
	@GetMapping(value="/login1/{id}/{pswd}")
	public String login1(@PathVariable String id,@PathVariable String pswd){
		return userService.login1(id,pswd);
	}
	
	@GetMapping(value="/login/{id}/{pswd}")
	public User login(@PathVariable String id,@PathVariable String pswd){
		return userService.login(id,pswd);
	}
	
//	@PutMapping(value="/update/{id}/{oldPswd}/{newPswd}")
//	public User update(@PathVariable int id,@PathVariable String oldPswd,@PathVariable String newPswd){
//		return userService.updatePswd(id,oldPswd,newPswd);
//	}
	@PutMapping(value="/update")
	public User update(@RequestBody Password pswdObj) throws CustomException{
		return userService.updatePswd(pswdObj);
	}
	
	@DeleteMapping(value="/deleteLeaveReq/{id}")
	public void deleteLeave(@PathVariable int id) {
		 userService.deleteLeavReq(id);
	}
	
	@PutMapping(value="/editleaveReq")
	public Leave editLeave(@RequestBody Leave leave) {
		return userService.editLeavReq(leave);
	}
	@PostMapping(value="/applyLeave")
	public Leave applyLeave(@RequestBody Leave leave) throws CustomException {
		//int temp = 0;
		if(leave != null) {
			for(Leave localLeave : getLeavesByUserId1(leave.getUserRef().getUserId())) {
/*********************************************************************************************************************************/
				if(localLeave.getFromDate().isEqual(leave.getFromDate()) && leave.getToDate().isEqual(localLeave.getToDate())){					
					if(localLeave.getStatus()==LeaveStatus.ACCEPTED)
						throw new CustomException("You are already applied leave from "+leave.getFromDate()+" to " +leave.getToDate());
					
					else if(localLeave.getStatus()==LeaveStatus.PENDING)						
						throw new CustomException("You are already applied leave from "+leave.getFromDate()+" to " +leave.getToDate()+ " but still waiting for approval");
				}
				
//				else if(localLeave.getFromDate().isEqual(leave.getFromDate()) || leave.getToDate().isEqual(localLeave.getToDate()) 
//						||localLeave.getFromDate().isEqual(leave.getToDate()) ||  localLeave.getToDate().isEqual(leave.getFromDate())
//						) {
				else if(localLeave.getFromDate().isEqual(leave.getFromDate()) || localLeave.getToDate().isEqual(leave.getFromDate())) {
					if(localLeave.getStatus()==LeaveStatus.ACCEPTED)
						throw new CustomException("You are already applied leave on (From-date) "+leave.getFromDate());
					
					else if(localLeave.getStatus()==LeaveStatus.PENDING)
						throw new CustomException("You are already applied leave on (From-date) "+leave.getFromDate()+" but still waiting for approval");
				}
				
				else if(localLeave.getFromDate().isEqual(leave.getToDate()) || localLeave.getToDate().isEqual(leave.getToDate())) {
					if(localLeave.getStatus()==LeaveStatus.ACCEPTED)
						throw new CustomException("You are already applied leave on (To-date) "+leave.getToDate());
					
					else if(localLeave.getStatus()==LeaveStatus.PENDING)
						throw new CustomException("You are already applied leave on (To-date)"+leave.getToDate()+" but still waiting for approval");
				}
				
				else if(( (leave.getFromDate().isAfter(localLeave.getFromDate()) ) && (leave.getFromDate().isBefore(localLeave.getToDate())) )) {
					if(localLeave.getStatus()==LeaveStatus.ACCEPTED)
						throw new CustomException("From-date is in the range of applied leave days " + leave.getFromDate());
					
					else if(localLeave.getStatus()==LeaveStatus.PENDING)
						throw new CustomException("From-date is in the range of applied leave days " + leave.getFromDate()+" but still waiting for approval");
					
					}
				else if(( (leave.getToDate().isAfter(localLeave.getFromDate()) ) && (leave.getToDate().isBefore(localLeave.getToDate())) )) {
					if(localLeave.getStatus()==LeaveStatus.ACCEPTED)
						throw new CustomException("To-date is in the range of applied leave days " + leave.getToDate());
					
					else if(localLeave.getStatus()==LeaveStatus.PENDING)
						throw new CustomException("To-date is in the range of applied leave days " + leave.getToDate()+" but still waiting for approval");
					
					}
		/****************************************************************************************************************************************/		
				else if(isWithinRange(localLeave.getFromDate(),leave.getFromDate(),leave.getToDate())) {
					if(localLeave.getStatus()==LeaveStatus.ACCEPTED)
						throw new CustomException("You are already applied leave on "+ localLeave.getFromDate());
					
					else if(localLeave.getStatus()==LeaveStatus.PENDING)
						throw new CustomException("You are already applied leave on "+ localLeave.getFromDate()+" but still waiting for approval");		
				}
				else if(isWithinRange(localLeave.getToDate(),leave.getFromDate(),leave.getToDate())) {
					if(localLeave.getStatus()==LeaveStatus.ACCEPTED)
						throw new CustomException("You are already applied leave on "+ localLeave.getToDate()+ " and again you are trying to apply leave from "+leave.getFromDate()+
								" to :"+leave.getToDate());
					
					else if(localLeave.getStatus()==LeaveStatus.PENDING)
						throw new CustomException("You are already applied leave on "+ localLeave.getToDate()+" but still waiting for approval"
					+ " and again you are trying to apply leave from "+leave.getFromDate()+" to :"+leave.getToDate());		
				}
					
				
				}
				return userService.applyLeave(leave);
		}
		else
			throw new CustomException("Please Enter Leave Details");
	}
	public boolean isWithinRange(LocalDate testDate,LocalDate from, LocalDate to) {
		return (testDate.isAfter(from)) &&( testDate.isBefore(to) );
	}
	/*
	@PostMapping(value="/applyLeave")
	public Leave applyLeave(@RequestBody Leave leave) throws CustomException {
		//int temp = 0;
		if(leave != null) {
			for(Leave localLeave : getLeavesByUserId1(leave.getUserRef().getUserId())) {
				
				if(localLeave.getFromDate().isEqual(leave.getFromDate()) && leave.getToDate().isEqual(localLeave.getToDate())){					
					if(localLeave.getStatus()==LeaveStatus.ACCEPTED)
						throw new CustomException("You are already applied leave from "+leave.getFromDate()+" to " +leave.getToDate());
					
					else if(localLeave.getStatus()==LeaveStatus.PENDING)						
						throw new CustomException("You are already applied leave from "+leave.getFromDate()+" to " +leave.getToDate()+ " but still waiting for approval");
				}
				
//				else if(localLeave.getFromDate().isEqual(leave.getFromDate()) || leave.getToDate().isEqual(localLeave.getToDate()) 
//						||localLeave.getFromDate().isEqual(leave.getToDate()) ||  localLeave.getToDate().isEqual(leave.getFromDate())
//						) {
				else if(localLeave.getFromDate().isEqual(leave.getFromDate()) || localLeave.getToDate().isEqual(leave.getFromDate())) {
					if(localLeave.getStatus()==LeaveStatus.ACCEPTED)
						throw new CustomException("You are already applied leave on (From-date) "+leave.getFromDate());
					
					else if(localLeave.getStatus()==LeaveStatus.PENDING)
						throw new CustomException("You are already applied leave on (From-date) "+leave.getFromDate()+" but still waiting for approval");
				}
				
				else if(localLeave.getFromDate().isEqual(leave.getToDate()) || localLeave.getToDate().isEqual(leave.getToDate())) {
					if(localLeave.getStatus()==LeaveStatus.ACCEPTED)
						throw new CustomException("You are already applied leave on (To-date) "+leave.getToDate());
					
					else if(localLeave.getStatus()==LeaveStatus.PENDING)
						throw new CustomException("You are already applied leave on (To-date)"+leave.getToDate()+" but still waiting for approval");
				}
				
				else if(( (leave.getFromDate().isAfter(localLeave.getFromDate()) ) && (leave.getFromDate().isBefore(localLeave.getToDate())) )) {
					if(localLeave.getStatus()==LeaveStatus.ACCEPTED)
						throw new CustomException("From-date is in the range of applied leave days " + leave.getFromDate());
					
					else if(localLeave.getStatus()==LeaveStatus.PENDING)
						throw new CustomException("From-date is in the range of applied leave days " + leave.getFromDate()+" but still waiting for approval");
					
					}
				else if(( (leave.getToDate().isAfter(localLeave.getFromDate()) ) && (leave.getToDate().isBefore(localLeave.getToDate())) )) {
					if(localLeave.getStatus()==LeaveStatus.ACCEPTED)
						throw new CustomException("To-date is in the range of applied leave days " + leave.getToDate());
					
					else if(localLeave.getStatus()==LeaveStatus.PENDING)
						throw new CustomException("To-date is in the range of applied leave days " + leave.getToDate()+" but still waiting for approval");
					
					}
				
				}
				return userService.applyLeave(leave);
		}
		else
			throw new CustomException("Please Enter Leave Details");
	}
	*/
	
	@GetMapping(value="/getLeavesByUserId1/{userId}")
	public List<Leave> getLeavesByUserId1(@PathVariable int userId){
		return userService.getUserLeavesList(userId);
	}
	
	@GetMapping(value="/getLeavesByUserId/{userId}")
	public List<LeaveDto> getLeavesByUserId(@PathVariable int userId){
		return userService.getUserLeavesListDto(userId);
	}
	
	@GetMapping(value="/{userId}")
	public User getUserById(@PathVariable int userId) throws CustomException{
		if(userService.getUserDetails(userId) != null)
			return userService.getUserDetails(userId);
		else 
			throw new CustomException("There is no user with that Id: " + userId);
	}
	@GetMapping(value="/getAllPendingList/{id}")
	public List<LeaveDto> getPendingLeaves(@PathVariable int id)throws CustomException{
		if(userService.getPendingLeavesById(id).size() != 0)
			return userService.getPendingLeavesById(id);
		else
			throw new CustomException("There is no pending Leaves");
	}
	
	@GetMapping(value="/getApprovedPendingList/{id}")
	public List<LeaveDto> getApprovedPendingLeaves(@PathVariable int id)throws CustomException{
		List<LeaveDto> leaveList = new ArrayList<LeaveDto>();
		if(userService.getPendingLeavesById(id).size() != 0)
			leaveList.addAll(userService.getPendingLeavesById(id)) ;
		if(userService.getApprovedLeavesById(id).size() != 0)
			leaveList.addAll(userService.getApprovedLeavesById(id)) ;
		System.out.println(leaveList);
		return leaveList;
	}

	
	@GetMapping(value="/getApprovedLeaves/{id}")
	public List<LeaveDto> getApprovedLeaves(@PathVariable int id) throws CustomException{
		if(userService.getApprovedLeavesById(id).size() != 0)
			return userService.getApprovedLeavesById(id);
		else
			throw new CustomException("There is no Approved Leaves ");
	}

	@GetMapping(value="/getRejectedLeaves/{id}")
	public List<LeaveDto> getRejectedLeaves(@PathVariable int id) throws CustomException{
		if(userService.getRejectedLeavesById(id).size() != 0)
		return userService.getRejectedLeavesById(id);
		else
			throw new CustomException("There is no Rejected Leaves ");
	}
}
