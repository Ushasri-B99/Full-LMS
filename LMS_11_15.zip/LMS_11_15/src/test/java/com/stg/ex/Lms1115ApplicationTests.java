package com.stg.ex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lms1115ApplicationTests {

	@Test
	void contextLoads() {
	}

}
